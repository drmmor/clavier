/**
 * Constantes globales de l'application
 */

export const Constants = {
    // Mode de débogage
    DEBUG_MODE: true,
    
    // Langues supportées
    SUPPORTED_LANGUAGES: {
        'ar': {
            code: 'ar',
            name: 'العربية',
            englishName: 'Arabic',
            direction: 'rtl',
            keyboard: 'arabic',
            flag: '🇸🇦'
        },
        'ar-ma': {
            code: 'ar-ma',
            name: 'الدارجة',
            englishName: 'Darija',
            direction: 'rtl',
            keyboard: 'darija',
            flag: '🇲🇦'
        },
        'fr': {
            code: 'fr',
            name: 'Français',
            englishName: 'French',
            direction: 'ltr',
            keyboard: 'french',
            flag: '🇫🇷'
        },
        'en': {
            code: 'en',
            name: 'English',
            englishName: 'English',
            direction: 'ltr',
            keyboard: 'english',
            flag: '🇺🇸'
        },
        'ber': {
            code: 'ber',
            name: 'ⵜⴰⵎⴰⵣⵉⵖⵜ',
            englishName: 'Amazigh',
            direction: 'ltr',
            keyboard: 'amazigh',
            flag: '🏔️'
        }
    },
    
    // Langues d'interface supportées
    INTERFACE_LANGUAGES: {
        'fr': {
            code: 'fr',
            name: 'Français',
            flag: '🇫🇷'
        },
        'en': {
            code: 'en',
            name: 'English',
            flag: '🇺🇸'
        },
        'ar': {
            code: 'ar',
            name: 'العربية',
            flag: '🇸🇦'
        }
    },
    
    // Préférences par défaut
    DEFAULT_PREFERENCES: {
        interfaceLanguage: 'fr',
        inputLanguage: 'ar',
        theme: 'default',
        autoSave: true,
        autoDetectLanguage: true,
        showKeyboardShortcuts: true,
        soundEnabled: false,
        keyboardLayout: 'standard'
    },
    
    // Configuration des claviers
    KEYBOARD_CONFIGS: {
        arabic: {
            id: 'arabic',
            name: 'العربية',
            layout: 'arabic-standard',
            direction: 'rtl',
            hasPhonetic: true
        },
        darija: {
            id: 'darija',
            name: 'الدارجة',
            layout: 'darija-extended',
            direction: 'rtl',
            hasPhonetic: true
        },
        french: {
            id: 'french',
            name: 'Français',
            layout: 'azerty',
            direction: 'ltr',
            hasPhonetic: false
        },
        english: {
            id: 'english',
            name: 'English',
            layout: 'qwerty',
            direction: 'ltr',
            hasPhonetic: false
        },
        amazigh: {
            id: 'amazigh',
            name: 'ⵜⴰⵎⴰⵣⵉⵖⵜ',
            layout: 'tifinagh',
            direction: 'ltr',
            hasPhonetic: true
        }
    },
    
    // Types de notifications
    NOTIFICATION_TYPES: {
        SUCCESS: 'success',
        ERROR: 'error',
        WARNING: 'warning',
        INFO: 'info'
    },
    
    // Événements de l'application
    EVENTS: {
        APP_INITIALIZED: 'app:initialized',
        LANGUAGE_CHANGED: 'app:language-changed',
        KEYBOARD_CHANGED: 'app:keyboard-changed',
        TEXT_CHANGED: 'app:text-changed',
        TAB_CHANGED: 'app:tab-changed',
        THEME_CHANGED: 'app:theme-changed'
    },
    
    // Configuration de l'API Google
    GOOGLE_API: {
        CLIENT_ID: '', // À configurer
        API_KEY: '', // À configurer
        DISCOVERY_DOCS: ['https://www.googleapis.com/discovery/v1/apis/blogger/v3/rest'],
        SCOPES: 'https://www.googleapis.com/auth/blogger'
    },
    
    // Limites et contraintes
    LIMITS: {
        MAX_TEXT_LENGTH: 50000,
        MAX_HISTORY_ENTRIES: 50,
        AUTO_SAVE_INTERVAL: 30000,
        NOTIFICATION_DURATION: 5000,
        DEBOUNCE_DELAY: 300
    },
    
    // Chemins des ressources
    PATHS: {
        DATA: './data/',
        LANGUAGES: './data/languages/',
        KEYBOARDS: './data/keyboards/',
        PHONETIC: './data/phonetic/',
        TRANSLATIONS: './data/translations/',
        FONTS: './assets/fonts/',
        IMAGES: './assets/images/'
    },
    
    // Configuration des exports
    EXPORT_FORMATS: {
        TXT: {
            id: 'txt',
            name: 'Texte (.txt)',
            mimeType: 'text/plain',
            extension: '.txt'
        },
        HTML: {
            id: 'html',
            name: 'HTML (.html)',
            mimeType: 'text/html',
            extension: '.html'
        },
        PDF: {
            id: 'pdf',
            name: 'PDF (.pdf)',
            mimeType: 'application/pdf',
            extension: '.pdf'
        },
        JSON: {
            id: 'json',
            name: 'JSON (.json)',
            mimeType: 'application/json',
            extension: '.json'
        }
    },
    
    // Messages d'erreur
    ERROR_MESSAGES: {
        NETWORK_ERROR: 'Erreur de connexion réseau',
        INVALID_INPUT: 'Données d\'entrée invalides',
        STORAGE_ERROR: 'Erreur de stockage local',
        API_ERROR: 'Erreur de l\'API',
        UNKNOWN_ERROR: 'Erreur inconnue'
    },
    
    // Regex patterns
    PATTERNS: {
        EMAIL: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
        URL: /^https?:\/\/.+/,
        ARABIC: /[\u0600-\u06FF\u0750-\u077F]/,
        LATIN: /[a-zA-Z]/,
        TIFINAGH: /[\u2D30-\u2D7F]/
    },
    
    // Configuration des thèmes
    THEMES: {
        DEFAULT: 'default',
        DARK: 'dark',
        HIGH_CONTRAST: 'high-contrast'
    }
};

/**
 * Classe utilitaire avec des fonctions helper
 */
export class Helpers {
    /**
     * Crée un délai (promesse qui se résout après un certain temps)
     */
    static delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
    
    /**
     * Fonction de debounce pour limiter la fréquence d'exécution
     */
    static debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }
    
    /**
     * Fonction de throttle pour limiter l'exécution
     */
    static throttle(func, limit) {
        let inThrottle;
        return function(...args) {
            if (!inThrottle) {
                func.apply(this, args);
                inThrottle = true;
                setTimeout(() => inThrottle = false, limit);
            }
        };
    }
    
    /**
     * Génère un ID unique
     */
    static generateId() {
        return Date.now().toString(36) + Math.random().toString(36).substr(2);
    }
    
    /**
     * Formate une date
     */
    static formatDate(date, locale = 'fr-FR') {
        return new Intl.DateTimeFormat(locale, {
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        }).format(date);
    }
    
    /**
     * Échappe les caractères HTML
     */
    static escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
    
    /**
     * Détecte la langue d'un texte (basique)
     */
    static detectLanguage(text) {
        if (!text || text.trim().length === 0) {
            return null;
        }
        
        // Détection basique basée sur les caractères
        if (Constants.PATTERNS.ARABIC.test(text)) {
            return 'ar';
        } else if (Constants.PATTERNS.TIFINAGH.test(text)) {
            return 'ber';
        } else if (Constants.PATTERNS.LATIN.test(text)) {
            // Détection plus fine entre français et anglais
            const frenchWords = ['le', 'la', 'les', 'de', 'du', 'des', 'et', 'à', 'un', 'une'];
            const englishWords = ['the', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of'];
            
            const words = text.toLowerCase().split(/\s+/);
            let frenchScore = 0;
            let englishScore = 0;
            
            words.forEach(word => {
                if (frenchWords.includes(word)) frenchScore++;
                if (englishWords.includes(word)) englishScore++;
            });
            
            if (frenchScore > englishScore) {
                return 'fr';
            } else if (englishScore > frenchScore) {
                return 'en';
            }
            
            // Par défaut, retourner français si pas de distinction claire
            return 'fr';
        }
        
        return null;
    }
    
    /**
     * Copie du texte dans le presse-papiers
     */
    static async copyToClipboard(text) {
        try {
            if (navigator.clipboard && window.isSecureContext) {
                await navigator.clipboard.writeText(text);
                return true;
            } else {
                // Fallback pour les navigateurs plus anciens
                const textArea = document.createElement('textarea');
                textArea.value = text;
                textArea.style.position = 'fixed';
                textArea.style.left = '-999999px';
                textArea.style.top = '-999999px';
                document.body.appendChild(textArea);
                textArea.focus();
                textArea.select();
                
                const result = document.execCommand('copy');
                document.body.removeChild(textArea);
                return result;
            }
        } catch (error) {
            console.error('Erreur lors de la copie:', error);
            return false;
        }
    }
    
    /**
     * Télécharge un fichier
     */
    static downloadFile(content, filename, mimeType = 'text/plain') {
        const blob = new Blob([content], { type: mimeType });
        const url = URL.createObjectURL(blob);
        
        const link = document.createElement('a');
        link.href = url;
        link.download = filename;
        link.style.display = 'none';
        
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        
        URL.revokeObjectURL(url);
    }
    
    /**
     * Valide une adresse email
     */
    static isValidEmail(email) {
        return Constants.PATTERNS.EMAIL.test(email);
    }
    
    /**
     * Valide une URL
     */
    static isValidUrl(url) {
        return Constants.PATTERNS.URL.test(url);
    }
    
    /**
     * Calcule les statistiques d'un texte
     */
    static getTextStatistics(text) {
        if (!text) {
            return {
                characters: 0,
                charactersNoSpaces: 0,
                words: 0,
                paragraphs: 0,
                sentences: 0,
                readingTime: 0
            };
        }
        
        const characters = text.length;
        const charactersNoSpaces = text.replace(/\s/g, '').length;
        const words = text.trim() ? text.trim().split(/\s+/).length : 0;
        const paragraphs = text.trim() ? text.split(/\n\s*\n/).length : 0;
        const sentences = text.trim() ? text.split(/[.!?]+/).filter(s => s.trim()).length : 0;
        
        // Estimation du temps de lecture (200 mots par minute)
        const readingTime = Math.ceil(words / 200);
        
        return {
            characters,
            charactersNoSpaces,
            words,
            paragraphs,
            sentences,
            readingTime
        };
    }
    
    /**
     * Formate un nombre avec des séparateurs
     */
    static formatNumber(number, locale = 'fr-FR') {
        return new Intl.NumberFormat(locale).format(number);
    }
    
    /**
     * Tronque un texte à une longueur donnée
     */
    static truncateText(text, maxLength, suffix = '...') {
        if (text.length <= maxLength) {
            return text;
        }
        return text.substring(0, maxLength - suffix.length) + suffix;
    }
    
    /**
     * Convertit un texte en slug (URL-friendly)
     */
    static slugify(text) {
        return text
            .toLowerCase()
            .trim()
            .replace(/[^\w\s-]/g, '')
            .replace(/[\s_-]+/g, '-')
            .replace(/^-+|-+$/g, '');
    }
    
    /**
     * Mélange un tableau (algorithme Fisher-Yates)
     */
    static shuffleArray(array) {
        const shuffled = [...array];
        for (let i = shuffled.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
        }
        return shuffled;
    }
    
    /**
     * Vérifie si un élément est visible dans le viewport
     */
    static isElementInViewport(element) {
        const rect = element.getBoundingClientRect();
        return (
            rect.top >= 0 &&
            rect.left >= 0 &&
            rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
            rect.right <= (window.innerWidth || document.documentElement.clientWidth)
        );
    }
    
    /**
     * Fait défiler jusqu'à un élément
     */
    static scrollToElement(element, behavior = 'smooth') {
        element.scrollIntoView({ behavior, block: 'center' });
    }
    
    /**
     * Charge un fichier JSON
     */
    static async loadJSON(url) {
        try {
            const response = await fetch(url);
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return await response.json();
        } catch (error) {
            console.error(`Erreur lors du chargement de ${url}:`, error);
            throw error;
        }
    }
    
    /**
     * Sauvegarde des données dans localStorage avec gestion d'erreur
     */
    static saveToStorage(key, data) {
        try {
            localStorage.setItem(key, JSON.stringify(data));
            return true;
        } catch (error) {
            console.error('Erreur lors de la sauvegarde:', error);
            return false;
        }
    }
    
    /**
     * Charge des données depuis localStorage
     */
    static loadFromStorage(key, defaultValue = null) {
        try {
            const item = localStorage.getItem(key);
            return item ? JSON.parse(item) : defaultValue;
        } catch (error) {
            console.error('Erreur lors du chargement:', error);
            return defaultValue;
        }
    }
}

/**
 * Classe EventEmitter simple pour la communication entre modules
 */
export class EventEmitter {
    constructor() {
        this.events = {};
    }
    
    /**
     * Ajoute un gestionnaire d'événement
     */
    on(event, callback) {
        if (!this.events[event]) {
            this.events[event] = [];
        }
        this.events[event].push(callback);
    }
    
    /**
     * Supprime un gestionnaire d'événement
     */
    off(event, callback) {
        if (!this.events[event]) return;
        
        this.events[event] = this.events[event].filter(cb => cb !== callback);
    }
    
    /**
     * Émet un événement
     */
    emit(event, ...args) {
        if (!this.events[event]) return;
        
        this.events[event].forEach(callback => {
            try {
                callback(...args);
            } catch (error) {
                console.error(`Erreur dans le gestionnaire d'événement ${event}:`, error);
            }
        });
    }
    
    /**
     * Ajoute un gestionnaire d'événement qui ne s'exécute qu'une fois
     */
    once(event, callback) {
        const onceCallback = (...args) => {
            callback(...args);
            this.off(event, onceCallback);
        };
        this.on(event, onceCallback);
    }
    
    /**
     * Supprime tous les gestionnaires d'événements
     */
    removeAllListeners(event = null) {
        if (event) {
            delete this.events[event];
        } else {
            this.events = {};
        }
    }
}

