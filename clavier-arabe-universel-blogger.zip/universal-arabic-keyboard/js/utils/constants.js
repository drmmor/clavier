/**
 * Constantes de l'application Clavier Arabe Universel
 * Ce fichier contient toutes les constantes utilisées dans l'application
 */

export const Constants = {
    // Mode de débogage
    DEBUG_MODE: true,
    
    // Version de l'application
    VERSION: '1.0.0',
    
    // Langues supportées pour la saisie
    SUPPORTED_LANGUAGES: {
        'ar': {
            code: 'ar',
            name: 'العربية',
            englishName: 'Arabic',
            direction: 'rtl',
            keyboard: 'arabic',
            flag: '🇸🇦',
            fontFamily: 'Noto Sans Arabic, Arial Unicode MS, Tahoma'
        },
        'ar-ma': {
            code: 'ar-ma',
            name: 'الدارجة',
            englishName: 'Darija',
            direction: 'rtl',
            keyboard: 'darija',
            flag: '🇲🇦',
            fontFamily: 'Noto Sans Arabic, Arial Unicode MS, Tahoma'
        },
        'fr': {
            code: 'fr',
            name: 'Français',
            englishName: 'French',
            direction: 'ltr',
            keyboard: 'french',
            flag: '🇫🇷',
            fontFamily: 'Noto Sans, Arial, sans-serif'
        },
        'en': {
            code: 'en',
            name: 'English',
            englishName: 'English',
            direction: 'ltr',
            keyboard: 'english',
            flag: '🇺🇸',
            fontFamily: 'Noto Sans, Arial, sans-serif'
        },
        'ber': {
            code: 'ber',
            name: 'ⵜⴰⵎⴰⵣⵉⵖⵜ',
            englishName: 'Amazigh',
            direction: 'ltr',
            keyboard: 'amazigh',
            flag: '🏔️',
            fontFamily: 'Tifinagh, Noto Sans Tifinagh, sans-serif'
        }
    },
    
    // Langues d'interface supportées
    INTERFACE_LANGUAGES: {
        'fr': {
            code: 'fr',
            name: 'Français',
            flag: '🇫🇷',
            direction: 'ltr'
        },
        'en': {
            code: 'en',
            name: 'English',
            flag: '🇺🇸',
            direction: 'ltr'
        },
        'ar': {
            code: 'ar',
            name: 'العربية',
            flag: '🇸🇦',
            direction: 'rtl'
        }
    },
    
    // Préférences par défaut de l'utilisateur
    DEFAULT_PREFERENCES: {
        interfaceLanguage: 'fr',
        inputLanguage: 'ar',
        theme: 'default',
        autoSave: true,
        autoDetectLanguage: true,
        showKeyboardShortcuts: true,
        soundEnabled: false,
        keyboardLayout: 'standard',
        fontSize: 'medium',
        showWordCount: true,
        enablePhonetic: true
    },
    
    // Configuration des claviers virtuels
    KEYBOARD_CONFIGS: {
        arabic: {
            id: 'arabic',
            name: 'العربية',
            layout: 'arabic-standard',
            direction: 'rtl',
            hasPhonetic: true,
            hasDiacritics: true,
            hasNumbers: true
        },
        darija: {
            id: 'darija',
            name: 'الدارجة',
            layout: 'darija-extended',
            direction: 'rtl',
            hasPhonetic: true,
            hasDiacritics: true,
            hasNumbers: true,
            hasCommonPhrases: true
        },
        french: {
            id: 'french',
            name: 'Français',
            layout: 'azerty',
            direction: 'ltr',
            hasPhonetic: false,
            hasAccents: true,
            hasNumbers: true
        },
        english: {
            id: 'english',
            name: 'English',
            layout: 'qwerty',
            direction: 'ltr',
            hasPhonetic: false,
            hasNumbers: true
        },
        amazigh: {
            id: 'amazigh',
            name: 'ⵜⴰⵎⴰⵣⵉⵖⵜ',
            layout: 'tifinagh',
            direction: 'ltr',
            hasPhonetic: true,
            hasNumbers: true,
            script: 'tifinagh'
        }
    },
    
    // Types de notifications
    NOTIFICATION_TYPES: {
        SUCCESS: 'success',
        ERROR: 'error',
        WARNING: 'warning',
        INFO: 'info'
    },
    
    // Événements de l'application
    EVENTS: {
        // Événements de l'application principale
        APP_INITIALIZED: 'app:initialized',
        APP_RESET: 'app:reset',
        APP_CONFIG_UPDATED: 'app:config-updated',
        
        // Événements de langue
        INTERFACE_LANGUAGE_CHANGED: 'app:interface-language-changed',
        INPUT_LANGUAGE_CHANGED: 'app:input-language-changed',
        LANGUAGE_DETECTED: 'language:detected',
        
        // Événements de clavier
        KEYBOARD_CHANGED: 'app:keyboard-changed',
        KEY_PRESSED: 'keyboard:key-pressed',
        
        // Événements de texte
        TEXT_CHANGED: 'app:text-changed',
        TEXT_STATS_UPDATED: 'app:stats-updated',
        
        // Événements d'interface
        TAB_CHANGED: 'app:tab-changed',
        THEME_CHANGED: 'app:theme-changed',
        MODAL_OPENED: 'ui:modal-opened',
        MODAL_CLOSED: 'ui:modal-closed',
        
        // Événements de notification
        NOTIFICATION_SHOWN: 'ui:notification-shown',
        NOTIFICATION_HIDDEN: 'ui:notification-hidden'
    },
    
    // Configuration de l'API Google Blogger
    GOOGLE_API: {
        CLIENT_ID: '', // À configurer avec votre client ID
        API_KEY: '', // À configurer avec votre API key
        DISCOVERY_DOCS: ['https://www.googleapis.com/discovery/v1/apis/blogger/v3/rest'],
        SCOPES: 'https://www.googleapis.com/auth/blogger',
        REDIRECT_URI: window.location.origin
    },
    
    // Limites et contraintes de l'application
    LIMITS: {
        MAX_TEXT_LENGTH: 50000,
        MAX_HISTORY_ENTRIES: 50,
        AUTO_SAVE_INTERVAL: 30000, // 30 secondes
        NOTIFICATION_DURATION: 5000, // 5 secondes
        DEBOUNCE_DELAY: 300, // 300ms
        THROTTLE_DELAY: 100, // 100ms
        MAX_SUGGESTIONS: 10,
        MIN_SEARCH_LENGTH: 2
    },
    
    // Chemins des ressources
    PATHS: {
        BASE: './',
        DATA: './data/',
        LANGUAGES: './data/languages/',
        KEYBOARDS: './data/keyboards/',
        PHONETIC: './data/phonetic/',
        TRANSLATIONS: './data/translations/',
        FONTS: './assets/fonts/',
        IMAGES: './assets/images/',
        CSS: './assets/css/',
        JS: './js/'
    },
    
    // Configuration des formats d'export
    EXPORT_FORMATS: {
        TXT: {
            id: 'txt',
            name: 'Texte (.txt)',
            description: 'Fichier texte simple',
            mimeType: 'text/plain',
            extension: '.txt',
            icon: '📄'
        },
        HTML: {
            id: 'html',
            name: 'HTML (.html)',
            description: 'Page web formatée',
            mimeType: 'text/html',
            extension: '.html',
            icon: '🌐'
        },
        PDF: {
            id: 'pdf',
            name: 'PDF (.pdf)',
            description: 'Document portable',
            mimeType: 'application/pdf',
            extension: '.pdf',
            icon: '📋'
        },
        JSON: {
            id: 'json',
            name: 'JSON (.json)',
            description: 'Données structurées',
            mimeType: 'application/json',
            extension: '.json',
            icon: '⚙️'
        }
    },
    
    // Messages d'erreur standardisés
    ERROR_MESSAGES: {
        NETWORK_ERROR: 'Erreur de connexion réseau',
        INVALID_INPUT: 'Données d\'entrée invalides',
        STORAGE_ERROR: 'Erreur de stockage local',
        API_ERROR: 'Erreur de l\'API',
        AUTH_ERROR: 'Erreur d\'authentification',
        PERMISSION_ERROR: 'Permissions insuffisantes',
        FILE_ERROR: 'Erreur de fichier',
        UNKNOWN_ERROR: 'Erreur inconnue',
        TIMEOUT_ERROR: 'Délai d\'attente dépassé',
        VALIDATION_ERROR: 'Erreur de validation'
    },
    
    // Expressions régulières utiles
    PATTERNS: {
        EMAIL: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
        URL: /^https?:\/\/.+/,
        ARABIC: /[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF]/,
        LATIN: /[a-zA-Z]/,
        TIFINAGH: /[\u2D30-\u2D7F]/,
        NUMBERS: /[0-9]/,
        ARABIC_NUMBERS: /[٠-٩]/,
        WHITESPACE: /\s+/,
        PUNCTUATION: /[.,;:!?'"()[\]{}\-]/,
        WORD_BOUNDARY: /\b/
    },
    
    // Configuration des thèmes
    THEMES: {
        DEFAULT: {
            id: 'default',
            name: 'Défaut',
            icon: '☀️'
        },
        DARK: {
            id: 'dark',
            name: 'Sombre',
            icon: '🌙'
        },
        HIGH_CONTRAST: {
            id: 'high-contrast',
            name: 'Contraste élevé',
            icon: '🔆'
        }
    },
    
    // Configuration des onglets
    TABS: {
        EDITOR: {
            id: 'editor',
            name: 'Éditeur',
            icon: '✍️'
        },
        PHONETIC: {
            id: 'phonetic',
            name: 'Phonétique',
            icon: '🔤'
        },
        TOOLS: {
            id: 'tools',
            name: 'Outils',
            icon: '🛠️'
        },
        EXPORT: {
            id: 'export',
            name: 'Export',
            icon: '📤'
        },
        BLOGGER: {
            id: 'blogger',
            name: 'Blogger',
            icon: '📝'
        }
    },
    
    // Configuration des raccourcis clavier
    KEYBOARD_SHORTCUTS: {
        COPY_ALL: { key: 'c', ctrl: true, description: 'Copier tout le texte' },
        SAVE: { key: 's', ctrl: true, description: 'Sauvegarder' },
        CLEAR: { key: 'Delete', ctrl: true, description: 'Effacer tout' },
        HELP: { key: 'F1', description: 'Afficher l\'aide' },
        ESCAPE: { key: 'Escape', description: 'Fermer les modales' },
        TOGGLE_DIRECTION: { key: 'd', ctrl: true, shift: true, description: 'Changer la direction du texte' }
    },
    
    // Configuration des sons (si activés)
    SOUNDS: {
        KEY_PRESS: {
            enabled: false,
            volume: 0.1,
            file: 'key-press.mp3'
        },
        NOTIFICATION: {
            enabled: false,
            volume: 0.3,
            file: 'notification.mp3'
        },
        SUCCESS: {
            enabled: false,
            volume: 0.2,
            file: 'success.mp3'
        },
        ERROR: {
            enabled: false,
            volume: 0.2,
            file: 'error.mp3'
        }
    },
    
    // Configuration de la conversion phonétique
    PHONETIC_CONFIG: {
        ENABLED_LANGUAGES: ['ar', 'ar-ma', 'ber'],
        MIN_INPUT_LENGTH: 1,
        MAX_SUGGESTIONS: 5,
        DEBOUNCE_DELAY: 200,
        CASE_SENSITIVE: false
    },
    
    // Configuration des statistiques de texte
    TEXT_STATS: {
        WORDS_PER_MINUTE_READING: 200,
        WORDS_PER_MINUTE_SPEAKING: 150,
        UPDATE_INTERVAL: 1000 // 1 seconde
    },
    
    // Configuration du stockage local
    STORAGE_KEYS: {
        PREFERENCES: 'uak-preferences',
        APP_STATE: 'uak-app-state',
        TEXT_CONTENT: 'uak-text-content',
        HISTORY: 'uak-history',
        CUSTOM_PHRASES: 'uak-custom-phrases',
        BLOGGER_AUTH: 'uak-blogger-auth'
    },
    
    // Configuration des animations
    ANIMATIONS: {
        DURATION_FAST: 150,
        DURATION_NORMAL: 300,
        DURATION_SLOW: 500,
        EASING: 'ease-in-out'
    },
    
    // Configuration responsive
    BREAKPOINTS: {
        MOBILE: 480,
        TABLET: 768,
        DESKTOP: 1024,
        LARGE: 1200
    },
    
    // Configuration de l'accessibilité
    ACCESSIBILITY: {
        FOCUS_VISIBLE: true,
        HIGH_CONTRAST_SUPPORT: true,
        SCREEN_READER_SUPPORT: true,
        KEYBOARD_NAVIGATION: true
    }
};

