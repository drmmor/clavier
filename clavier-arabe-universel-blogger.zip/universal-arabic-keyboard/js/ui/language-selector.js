/**
 * Module LanguageSelector pour la sélection de langue d'interface
 * Gère le sélecteur de langue dans l'en-tête de l'application.
 */

import { EventEmitter } from "../utils/helpers.js";
import { Constants } from "../utils/constants.js";

export class LanguageSelector extends EventEmitter {
    constructor() {
        super();
        this.selectorElement = null;
        this.buttonElement = null;
        this.menuElement = null;
        this.isMenuOpen = false;
        this.currentLanguage = Constants.DEFAULT_PREFERENCES.interfaceLanguage;
        console.log("🌐 LanguageSelector créé");
    }

    /**
     * Initialise le sélecteur de langue
     */
    init() {
        this.selectorElement = document.querySelector(".language-selector");
        if (!this.selectorElement) {
            console.error("❌ Élément .language-selector non trouvé dans le DOM.");
            return;
        }

        this.buttonElement = this.selectorElement.querySelector(".language-btn");
        this.menuElement = this.selectorElement.querySelector(".language-menu");

        if (!this.buttonElement || !this.menuElement) {
            console.error("❌ Éléments du sélecteur de langue non trouvés.");
            return;
        }

        this.setupEventListeners();
        this.populateLanguageMenu();
        this.updateCurrentLanguageDisplay();
        console.log("✅ LanguageSelector initialisé");
    }

    /**
     * Configure les écouteurs d'événements
     */
    setupEventListeners() {
        // Clic sur le bouton pour ouvrir/fermer le menu
        this.buttonElement.addEventListener("click", (event) => {
            event.stopPropagation();
            this.toggleMenu();
        });

        // Clic sur une option de langue
        this.menuElement.addEventListener("click", (event) => {
            const option = event.target.closest(".language-option");
            if (option) {
                const langCode = option.dataset.lang;
                this.selectLanguage(langCode);
            }
        });

        // Fermer le menu en cliquant ailleurs
        document.addEventListener("click", (event) => {
            if (!this.selectorElement.contains(event.target)) {
                this.closeMenu();
            }
        });

        // Fermer le menu avec la touche Échap
        document.addEventListener("keydown", (event) => {
            if (event.key === "Escape" && this.isMenuOpen) {
                this.closeMenu();
            }
        });
    }

    /**
     * Remplit le menu déroulant avec les langues disponibles
     */
    populateLanguageMenu() {
        this.menuElement.innerHTML = "";

        Object.values(Constants.INTERFACE_LANGUAGES).forEach(lang => {
            const option = document.createElement("button");
            option.className = "language-option";
            option.dataset.lang = lang.code;
            option.innerHTML = `
                <span class="language-flag">${lang.flag}</span>
                <span class="language-name">${lang.name}</span>
            `;
            this.menuElement.appendChild(option);
        });
    }

    /**
     * Met à jour l'affichage de la langue actuelle
     */
    updateCurrentLanguageDisplay() {
        const currentLang = Constants.INTERFACE_LANGUAGES[this.currentLanguage];
        if (currentLang && this.buttonElement) {
            this.buttonElement.innerHTML = `
                <span class="language-flag">${currentLang.flag}</span>
                <span class="language-name">${currentLang.name}</span>
                <span class="language-arrow">▼</span>
            `;
        }
    }

    /**
     * Bascule l'état du menu (ouvert/fermé)
     */
    toggleMenu() {
        if (this.isMenuOpen) {
            this.closeMenu();
        } else {
            this.openMenu();
        }
    }

    /**
     * Ouvre le menu déroulant
     */
    openMenu() {
        this.menuElement.classList.remove("hidden");
        this.menuElement.classList.add("visible");
        this.isMenuOpen = true;
        
        // Animation d'ouverture
        setTimeout(() => {
            this.menuElement.style.opacity = "1";
            this.menuElement.style.transform = "translateY(0)";
        }, 10);

        console.log("🌐 Menu de langue ouvert");
    }

    /**
     * Ferme le menu déroulant
     */
    closeMenu() {
        if (!this.isMenuOpen) return;

        this.menuElement.style.opacity = "0";
        this.menuElement.style.transform = "translateY(-10px)";
        
        setTimeout(() => {
            this.menuElement.classList.add("hidden");
            this.menuElement.classList.remove("visible");
            this.isMenuOpen = false;
        }, 200);

        console.log("🌐 Menu de langue fermé");
    }

    /**
     * Sélectionne une langue
     * @param {string} langCode - Code de la langue à sélectionner
     */
    selectLanguage(langCode) {
        if (!Constants.INTERFACE_LANGUAGES[langCode]) {
            console.warn(`Langue d'interface non supportée: ${langCode}`);
            return;
        }

        if (langCode !== this.currentLanguage) {
            this.currentLanguage = langCode;
            this.updateCurrentLanguageDisplay();
            this.emit("language-selected", langCode);
            console.log(`🌐 Langue d'interface sélectionnée: ${langCode}`);
        }

        this.closeMenu();
    }

    /**
     * Définit la langue actuelle (appelé depuis l'extérieur)
     * @param {string} langCode - Code de la langue
     */
    setCurrentLanguage(langCode) {
        if (Constants.INTERFACE_LANGUAGES[langCode]) {
            this.currentLanguage = langCode;
            this.updateCurrentLanguageDisplay();
        }
    }

    /**
     * Récupère la langue actuellement sélectionnée
     * @returns {string}
     */
    getCurrentLanguage() {
        return this.currentLanguage;
    }

    /**
     * Vérifie si le menu est ouvert
     * @returns {boolean}
     */
    isMenuOpened() {
        return this.isMenuOpen;
    }

    /**
     * Nettoie les ressources
     */
    destroy() {
        this.removeAllListeners();
        this.closeMenu();
        console.log("🗑️ LanguageSelector détruit");
    }
}

