/**
 * Module Notifications pour la gestion des messages de notification
 * Gère l'affichage des notifications toast dans l'interface utilisateur.
 */

import { EventEmitter, Helpers } from "../utils/helpers.js";
import { Constants } from "../utils/constants.js";

export class Notifications extends EventEmitter {
    constructor() {
        super();
        this.container = null;
        this.notifications = new Map(); // Stocke les notifications actives
        this.notificationCounter = 0;
        console.log("🔔 Notifications créé");
    }

    /**
     * Initialise le module Notifications
     */
    init() {
        this.createNotificationContainer();
        console.log("✅ Notifications initialisé");
    }

    /**
     * Crée le conteneur des notifications
     */
    createNotificationContainer() {
        this.container = document.createElement("div");
        this.container.className = "notifications-container";
        document.body.appendChild(this.container);
    }

    /**
     * Affiche une notification
     * @param {object} options - Options de configuration de la notification
     * @param {string} options.type - Type de notification ('success', 'error', 'warning', 'info')
     * @param {string} options.title - Titre de la notification
     * @param {string} options.message - Message de la notification
     * @param {number} [options.duration] - Durée d'affichage en millisecondes (0 = permanent)
     * @param {Array} [options.actions] - Actions disponibles dans la notification
     * @param {boolean} [options.closable] - Si la notification peut être fermée manuellement
     */
    show(options = {}) {
        const {
            type = Constants.NOTIFICATION_TYPES.INFO,
            title = "",
            message = "",
            duration = Constants.LIMITS.NOTIFICATION_DURATION,
            actions = [],
            closable = true
        } = options;

        const notificationId = ++this.notificationCounter;
        const notification = this.createNotificationElement(notificationId, type, title, message, actions, closable);

        // Ajouter la notification au conteneur
        this.container.appendChild(notification);
        this.notifications.set(notificationId, notification);

        // Animation d'entrée
        setTimeout(() => {
            notification.classList.add("slide-in");
        }, 10);

        // Fermeture automatique si une durée est spécifiée
        if (duration > 0) {
            setTimeout(() => {
                this.hide(notificationId);
            }, duration);
        }

        this.emit(Constants.EVENTS.NOTIFICATION_SHOWN, { id: notificationId, type, title, message });
        console.log(`🔔 Notification affichée: ${type} - ${title}`);

        return notificationId;
    }

    /**
     * Crée l'élément DOM de la notification
     * @param {number} id - ID unique de la notification
     * @param {string} type - Type de notification
     * @param {string} title - Titre de la notification
     * @param {string} message - Message de la notification
     * @param {Array} actions - Actions disponibles
     * @param {boolean} closable - Si la notification peut être fermée
     * @returns {HTMLElement} - Élément DOM de la notification
     */
    createNotificationElement(id, type, title, message, actions, closable) {
        const notification = document.createElement("div");
        notification.className = `notification ${type}`;
        notification.dataset.notificationId = id;

        const iconMap = {
            [Constants.NOTIFICATION_TYPES.SUCCESS]: "✅",
            [Constants.NOTIFICATION_TYPES.ERROR]: "❌",
            [Constants.NOTIFICATION_TYPES.WARNING]: "⚠️",
            [Constants.NOTIFICATION_TYPES.INFO]: "ℹ️"
        };

        let actionsHtml = "";
        if (actions.length > 0) {
            actionsHtml = `
                <div class="notification-actions">
                    ${actions.map(action => `
                        <button class="notification-action btn btn-sm ${action.class || 'btn-secondary'}" 
                                data-action="${action.id || ''}">
                            ${action.text}
                        </button>
                    `).join("")}
                </div>
            `;
        }

        notification.innerHTML = `
            <div class="notification-content">
                <div class="notification-header">
                    <span class="notification-icon">${iconMap[type] || "ℹ️"}</span>
                    ${title ? `<span class="notification-title">${Helpers.escapeHtml(title)}</span>` : ""}
                    ${closable ? `<button class="notification-close" type="button">&times;</button>` : ""}
                </div>
                ${message ? `<div class="notification-message">${Helpers.escapeHtml(message)}</div>` : ""}
                ${actionsHtml}
            </div>
        `;

        // Gestionnaires d'événements
        if (closable) {
            const closeButton = notification.querySelector(".notification-close");
            closeButton.addEventListener("click", () => {
                this.hide(id);
            });
        }

        // Gestionnaires pour les actions
        actions.forEach(action => {
            const actionButton = notification.querySelector(`[data-action="${action.id || ''}"]`);
            if (actionButton) {
                actionButton.addEventListener("click", () => {
                    if (action.action) {
                        action.action();
                    }
                    if (action.closeNotification !== false) {
                        this.hide(id);
                    }
                });
            }
        });

        return notification;
    }

    /**
     * Masque une notification spécifique
     * @param {number} notificationId - ID de la notification à masquer
     */
    hide(notificationId) {
        const notification = this.notifications.get(notificationId);
        if (!notification) return;

        // Animation de sortie
        notification.style.transform = "translateX(100%)";
        notification.style.opacity = "0";

        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
            this.notifications.delete(notificationId);
        }, 300);

        this.emit(Constants.EVENTS.NOTIFICATION_HIDDEN, { id: notificationId });
        console.log(`🔔 Notification masquée: ${notificationId}`);
    }

    /**
     * Masque toutes les notifications
     */
    hideAll() {
        this.notifications.forEach((notification, id) => {
            this.hide(id);
        });
    }

    /**
     * Affiche une notification de succès
     * @param {string} title - Titre de la notification
     * @param {string} message - Message de la notification
     * @param {number} [duration] - Durée d'affichage
     */
    success(title, message, duration) {
        return this.show({
            type: Constants.NOTIFICATION_TYPES.SUCCESS,
            title,
            message,
            duration
        });
    }

    /**
     * Affiche une notification d'erreur
     * @param {string} title - Titre de la notification
     * @param {string} message - Message de la notification
     * @param {number} [duration] - Durée d'affichage
     */
    error(title, message, duration) {
        return this.show({
            type: Constants.NOTIFICATION_TYPES.ERROR,
            title,
            message,
            duration: duration || 0 // Les erreurs restent affichées par défaut
        });
    }

    /**
     * Affiche une notification d'avertissement
     * @param {string} title - Titre de la notification
     * @param {string} message - Message de la notification
     * @param {number} [duration] - Durée d'affichage
     */
    warning(title, message, duration) {
        return this.show({
            type: Constants.NOTIFICATION_TYPES.WARNING,
            title,
            message,
            duration
        });
    }

    /**
     * Affiche une notification d'information
     * @param {string} title - Titre de la notification
     * @param {string} message - Message de la notification
     * @param {number} [duration] - Durée d'affichage
     */
    info(title, message, duration) {
        return this.show({
            type: Constants.NOTIFICATION_TYPES.INFO,
            title,
            message,
            duration
        });
    }

    /**
     * Affiche une notification avec des actions
     * @param {object} options - Options de configuration complètes
     */
    showWithActions(options) {
        return this.show(options);
    }

    /**
     * Compte le nombre de notifications actives
     * @returns {number}
     */
    getActiveCount() {
        return this.notifications.size;
    }

    /**
     * Nettoie les ressources
     */
    destroy() {
        this.removeAllListeners();
        this.hideAll();
        if (this.container) {
            document.body.removeChild(this.container);
        }
        console.log("🗑️ Notifications détruit");
    }
}

