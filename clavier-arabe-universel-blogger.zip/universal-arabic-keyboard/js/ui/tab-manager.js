
/**
 * Module de gestion des onglets (TabManager)
 * Gère l'activation et la désactivation des onglets de l'interface utilisateur.
 */

import { EventEmitter } from "../utils/helpers.js";
import { Constants } from "../utils/constants.js";

export class TabManager extends EventEmitter {
    constructor() {
        super();
        this.tabsContainer = document.querySelector(".tabs");
        this.tabPanesContainer = document.querySelector(".tab-content");
        this.activeTabId = Constants.TABS.EDITOR.id; // Onglet actif par défaut
        console.log("🗂️ TabManager créé");
    }

    /**
     * Initialise le gestionnaire d'onglets
     */
    init() {
        if (!this.tabsContainer || !this.tabPanesContainer) {
            console.error("❌ Éléments des onglets non trouvés dans le DOM.");
            return;
        }
        this.setupEventListeners();
        this.activateTab(this.activeTabId); // Activer l'onglet par défaut
        console.log("✅ TabManager initialisé");
    }

    /**
     * Configure les écouteurs d'événements pour les onglets
     */
    setupEventListeners() {
        this.tabsContainer.addEventListener("click", this.handleTabClick.bind(this));
    }

    /**
     * Gère le clic sur un onglet
     * @param {Event} event - L'événement de clic
     */
    handleTabClick(event) {
        const target = event.target.closest(".tab");
        if (!target) return;

        const tabId = target.dataset.tabId;
        if (tabId && tabId !== this.activeTabId) {
            this.activateTab(tabId);
        }
    }

    /**
     * Active un onglet spécifique
     * @param {string} tabId - L'ID de l'onglet à activer
     */
    activateTab(tabId) {
        // Désactiver l'onglet précédemment actif
        const currentActiveTab = this.tabsContainer.querySelector(`.tab.active`);
        const currentActivePane = this.tabPanesContainer.querySelector(`.tab-pane.active`);
        if (currentActiveTab) {
            currentActiveTab.classList.remove("active");
        }
        if (currentActivePane) {
            currentActivePane.classList.remove("active");
        }

        // Activer le nouvel onglet
        const newActiveTab = this.tabsContainer.querySelector(`.tab[data-tab-id="${tabId}"]`);
        const newActivePane = this.tabPanesContainer.querySelector(`.tab-pane[data-tab-id="${tabId}"]`);
        if (newActiveTab) {
            newActiveTab.classList.add("active");
        }
        if (newActivePane) {
            newActivePane.classList.add("active");
        }

        this.activeTabId = tabId;
        this.emit(Constants.EVENTS.TAB_CHANGED, tabId);
        console.log(`➡️ Onglet activé: ${tabId}`);
    }

    /**
     * Récupère l'ID de l'onglet actif
     * @returns {string}
     */
    getActiveTabId() {
        return this.activeTabId;
    }

    /**
     * Réinitialise le gestionnaire d'onglets à son état par défaut
     */
    reset() {
        this.activateTab(Constants.TABS.EDITOR.id);
        console.log("🔄 TabManager réinitialisé");
    }

    /**
     * Nettoie les ressources
     */
    destroy() {
        this.removeAllListeners();
        if (this.tabsContainer) {
            this.tabsContainer.removeEventListener("click", this.handleTabClick);
        }
        console.log("🗑️ TabManager détruit");
    }
}


