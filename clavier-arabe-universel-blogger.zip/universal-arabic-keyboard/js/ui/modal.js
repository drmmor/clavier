/**
 * Module Modal pour la gestion des fenêtres modales
 * Gère l'affichage et la fermeture des modales dans l'interface utilisateur.
 */

import { EventEmitter } from "../utils/helpers.js";
import { Constants } from "../utils/constants.js";

export class Modal extends EventEmitter {
    constructor() {
        super();
        this.modalOverlay = null;
        this.isOpen = false;
        console.log("🪟 Modal créé");
    }

    /**
     * Initialise le module Modal
     */
    init() {
        this.createModalStructure();
        this.setupEventListeners();
        console.log("✅ Modal initialisé");
    }

    /**
     * Crée la structure HTML de la modale
     */
    createModalStructure() {
        this.modalOverlay = document.createElement("div");
        this.modalOverlay.className = "modal-overlay hidden";
        this.modalOverlay.innerHTML = `
            <div class="modal-content">
                <div class="modal-header">
                    <h3 class="modal-title"></h3>
                    <button class="modal-close" type="button">&times;</button>
                </div>
                <div class="modal-body"></div>
                <div class="modal-footer hidden"></div>
            </div>
        `;
        document.body.appendChild(this.modalOverlay);
    }

    /**
     * Configure les écouteurs d'événements pour la modale
     */
    setupEventListeners() {
        // Fermer la modale en cliquant sur l'overlay
        this.modalOverlay.addEventListener("click", (event) => {
            if (event.target === this.modalOverlay) {
                this.close();
            }
        });

        // Fermer la modale en cliquant sur le bouton de fermeture
        const closeButton = this.modalOverlay.querySelector(".modal-close");
        closeButton.addEventListener("click", () => {
            this.close();
        });

        // Fermer la modale avec la touche Échap
        document.addEventListener("keydown", (event) => {
            if (event.key === "Escape" && this.isOpen) {
                this.close();
            }
        });
    }

    /**
     * Affiche la modale avec le contenu spécifié
     * @param {object} options - Options de configuration de la modale
     * @param {string} options.title - Titre de la modale
     * @param {string} options.content - Contenu HTML de la modale
     * @param {string} [options.size] - Taille de la modale ('small', 'medium', 'large')
     * @param {Array} [options.buttons] - Boutons à afficher dans le pied de page
     */
    show(options = {}) {
        const { title = "", content = "", size = "medium", buttons = [] } = options;

        // Définir le titre
        const titleElement = this.modalOverlay.querySelector(".modal-title");
        titleElement.textContent = title;

        // Définir le contenu
        const bodyElement = this.modalOverlay.querySelector(".modal-body");
        bodyElement.innerHTML = content;

        // Définir la taille
        const modalContent = this.modalOverlay.querySelector(".modal-content");
        modalContent.className = `modal-content modal-${size}`;

        // Gérer les boutons du pied de page
        const footerElement = this.modalOverlay.querySelector(".modal-footer");
        if (buttons.length > 0) {
            footerElement.innerHTML = "";
            buttons.forEach(button => {
                const buttonElement = document.createElement("button");
                buttonElement.className = `btn ${button.class || "btn-secondary"}`;
                buttonElement.textContent = button.text;
                buttonElement.addEventListener("click", () => {
                    if (button.action) {
                        button.action();
                    }
                    if (button.closeModal !== false) {
                        this.close();
                    }
                });
                footerElement.appendChild(buttonElement);
            });
            footerElement.classList.remove("hidden");
        } else {
            footerElement.classList.add("hidden");
        }

        // Afficher la modale
        this.modalOverlay.classList.remove("hidden");
        this.modalOverlay.classList.add("fade-in");
        this.isOpen = true;

        // Empêcher le défilement de la page
        document.body.style.overflow = "hidden";

        this.emit(Constants.EVENTS.MODAL_OPENED, options);
        console.log("🪟 Modale ouverte:", title);
    }

    /**
     * Ferme la modale
     */
    close() {
        if (!this.isOpen) return;

        this.modalOverlay.classList.add("hidden");
        this.modalOverlay.classList.remove("fade-in");
        this.isOpen = false;

        // Restaurer le défilement de la page
        document.body.style.overflow = "";

        this.emit(Constants.EVENTS.MODAL_CLOSED);
        console.log("🪟 Modale fermée");
    }

    /**
     * Vérifie si la modale est ouverte
     * @returns {boolean}
     */
    isModalOpen() {
        return this.isOpen;
    }

    /**
     * Affiche une modale de confirmation
     * @param {object} options - Options de configuration
     * @param {string} options.title - Titre de la confirmation
     * @param {string} options.message - Message de confirmation
     * @param {function} options.onConfirm - Fonction à exécuter lors de la confirmation
     * @param {function} [options.onCancel] - Fonction à exécuter lors de l'annulation
     */
    showConfirmation(options = {}) {
        const { title = "Confirmation", message = "", onConfirm, onCancel } = options;

        this.show({
            title,
            content: `<p>${message}</p>`,
            size: "small",
            buttons: [
                {
                    text: "Annuler",
                    class: "btn-secondary",
                    action: onCancel
                },
                {
                    text: "Confirmer",
                    class: "btn-primary",
                    action: onConfirm
                }
            ]
        });
    }

    /**
     * Affiche une modale d'alerte
     * @param {object} options - Options de configuration
     * @param {string} options.title - Titre de l'alerte
     * @param {string} options.message - Message d'alerte
     * @param {string} [options.type] - Type d'alerte ('info', 'warning', 'error', 'success')
     */
    showAlert(options = {}) {
        const { title = "Information", message = "", type = "info" } = options;

        const iconMap = {
            info: "ℹ️",
            warning: "⚠️",
            error: "❌",
            success: "✅"
        };

        this.show({
            title: `${iconMap[type]} ${title}`,
            content: `<p>${message}</p>`,
            size: "small",
            buttons: [
                {
                    text: "OK",
                    class: "btn-primary"
                }
            ]
        });
    }

    /**
     * Nettoie les ressources
     */
    destroy() {
        this.removeAllListeners();
        if (this.modalOverlay) {
            document.body.removeChild(this.modalOverlay);
        }
        console.log("🗑️ Modal détruit");
    }
}

