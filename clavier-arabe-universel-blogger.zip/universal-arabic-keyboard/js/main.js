/**
 * Point d'entrée principal de l'application Clavier Arabe Universel
 * Initialise tous les modules et coordonne le démarrage de l'application
 */

// Import des modules principaux
import { App } from './core/app.js';
import { LanguageManager } from './core/language-manager.js';
import { KeyboardManager } from './core/keyboard-manager.js';
import { TextProcessor } from './core/text-processor.js';
import { Storage } from './core/storage.js';

// Import des modules d'interface utilisateur
import { TabManager } from './ui/tab-manager.js';
import { Modal } from './ui/modal.js';
import { Notifications } from './ui/notifications.js';
import { LanguageSelector } from './ui/language-selector.js';

// Import des utilitaires
import { Constants } from './utils/constants.js';
import { Helpers } from './utils/helpers.js';

/**
 * Classe principale pour l'initialisation de l'application
 */
class MainApp {
    constructor() {
        this.app = null;
        this.isInitialized = false;
        this.loadingElement = null;
        this.appElement = null;
    }

    /**
     * Initialise l'application
     */
    async init() {
        try {
            console.log('🚀 Initialisation de l\'application Clavier Arabe Universel...');
            
            // Récupération des éléments DOM principaux
            this.loadingElement = document.getElementById('app-loader');
            this.appElement = document.getElementById('app');
            
            if (!this.loadingElement || !this.appElement) {
                throw new Error('Éléments DOM principaux non trouvés');
            }

            // Affichage du loader
            this.showLoader();

            // Initialisation du stockage local
            await this.initStorage();

            // Initialisation des modules principaux
            await this.initCoreModules();

            // Initialisation de l'interface utilisateur
            await this.initUI();

            // Chargement des données initiales
            await this.loadInitialData();

            // Configuration des gestionnaires d'événements globaux
            this.setupGlobalEventListeners();

            // Finalisation de l'initialisation
            await this.finishInitialization();

            console.log('✅ Application initialisée avec succès');
            
        } catch (error) {
            console.error('❌ Erreur lors de l\'initialisation:', error);
            this.showError('Erreur lors du chargement de l\'application. Veuillez recharger la page.');
        }
    }

    /**
     * Affiche le loader de chargement
     */
    showLoader() {
        if (this.loadingElement) {
            this.loadingElement.style.display = 'flex';
        }
        if (this.appElement) {
            this.appElement.style.display = 'none';
        }
    }

    /**
     * Cache le loader et affiche l'application
     */
    hideLoader() {
        if (this.loadingElement) {
            this.loadingElement.style.display = 'none';
        }
        if (this.appElement) {
            this.appElement.style.display = 'block';
            this.appElement.classList.add('fade-in');
        }
    }

    /**
     * Initialise le système de stockage local
     */
    async initStorage() {
        console.log('📦 Initialisation du stockage...');
        
        // Vérification du support localStorage
        if (!Storage.isSupported()) {
            console.warn('⚠️ localStorage non supporté, utilisation de la mémoire temporaire');
        }

        // Chargement des préférences utilisateur
        const preferences = Storage.getPreferences();
        console.log('👤 Préférences utilisateur chargées:', preferences);
    }

    /**
     * Initialise les modules principaux de l'application
     */
    async initCoreModules() {
        console.log('🔧 Initialisation des modules principaux...');

        // Initialisation du gestionnaire de langues
        const languageManager = new LanguageManager();
        await languageManager.init();

        // Initialisation du gestionnaire de claviers
        const keyboardManager = new KeyboardManager();
        await keyboardManager.init();

        // Initialisation du processeur de texte
        const textProcessor = new TextProcessor();
        await textProcessor.init();

        // Initialisation de l'application principale
        this.app = new App({
            languageManager,
            keyboardManager,
            textProcessor
        });

        await this.app.init();
    }

    /**
     * Initialise l'interface utilisateur
     */
    async initUI() {
        console.log('🎨 Initialisation de l\'interface utilisateur...');

        // Initialisation du gestionnaire d'onglets
        const tabManager = new TabManager();
        tabManager.init();

        // Initialisation du système de notifications
        const notifications = new Notifications();
        notifications.init();

        // Initialisation des modales
        const modal = new Modal();
        modal.init();

        // Initialisation du sélecteur de langue d'interface
        const languageSelector = new LanguageSelector();
        languageSelector.init();

        // Stockage des références dans l'app principale
        this.app.setUIComponents({
            tabManager,
            notifications,
            modal,
            languageSelector
        });
    }

    /**
     * Charge les données initiales nécessaires
     */
    async loadInitialData() {
        console.log('📊 Chargement des données initiales...');

        try {
            // Chargement des traductions pour la langue par défaut
            await this.app.languageManager.loadTranslations();

            // Chargement des configurations de claviers
            await this.app.keyboardManager.loadKeyboardConfigs();

            // Application des préférences utilisateur
            await this.applyUserPreferences();

        } catch (error) {
            console.error('❌ Erreur lors du chargement des données:', error);
            // Continuer avec les données par défaut
        }
    }

    /**
     * Applique les préférences utilisateur sauvegardées
     */
    async applyUserPreferences() {
        const preferences = Storage.getPreferences();

        // Application de la langue d'interface
        if (preferences.interfaceLanguage) {
            await this.app.languageManager.setInterfaceLanguage(preferences.interfaceLanguage);
        }

        // Application de la langue de saisie
        if (preferences.inputLanguage) {
            await this.app.keyboardManager.setActiveLanguage(preferences.inputLanguage);
        }

        // Application du thème
        if (preferences.theme) {
            this.applyTheme(preferences.theme);
        }

        console.log('✅ Préférences utilisateur appliquées');
    }

    /**
     * Applique un thème à l'interface
     */
    applyTheme(theme) {
        const body = document.body;
        body.className = body.className.replace(/theme-\w+/g, '');
        body.classList.add(`theme-${theme}`);
    }

    /**
     * Configure les gestionnaires d'événements globaux
     */
    setupGlobalEventListeners() {
        console.log('🎯 Configuration des gestionnaires d\'événements...');

        // Gestionnaire pour les raccourcis clavier globaux
        document.addEventListener('keydown', this.handleGlobalKeydown.bind(this));

        // Gestionnaire pour la fermeture des menus déroulants
        document.addEventListener('click', this.handleGlobalClick.bind(this));

        // Gestionnaire pour le redimensionnement de la fenêtre
        window.addEventListener('resize', Helpers.debounce(this.handleWindowResize.bind(this), 250));

        // Gestionnaire pour la visibilité de la page
        document.addEventListener('visibilitychange', this.handleVisibilityChange.bind(this));

        // Gestionnaire pour les erreurs JavaScript non capturées
        window.addEventListener('error', this.handleGlobalError.bind(this));

        // Gestionnaire pour les promesses rejetées non capturées
        window.addEventListener('unhandledrejection', this.handleUnhandledRejection.bind(this));
    }

    /**
     * Gestionnaire pour les raccourcis clavier globaux
     */
    handleGlobalKeydown(event) {
        // Ctrl/Cmd + S : Sauvegarder le contenu
        if ((event.ctrlKey || event.metaKey) && event.key === 's') {
            event.preventDefault();
            this.app.textProcessor.saveContent();
        }

        // Ctrl/Cmd + C : Copier le contenu (si aucune sélection)
        if ((event.ctrlKey || event.metaKey) && event.key === 'c' && !window.getSelection().toString()) {
            event.preventDefault();
            this.app.textProcessor.copyContent();
        }

        // Échap : Fermer les modales et menus
        if (event.key === 'Escape') {
            this.app.ui.modal.close();
            this.app.ui.languageSelector.closeMenu();
        }

        // F1 : Afficher l'aide
        if (event.key === 'F1') {
            event.preventDefault();
            this.showHelp();
        }
    }

    /**
     * Gestionnaire pour les clics globaux
     */
    handleGlobalClick(event) {
        // Fermeture automatique des menus déroulants
        if (!event.target.closest('.language-selector')) {
            this.app.ui.languageSelector.closeMenu();
        }
    }

    /**
     * Gestionnaire pour le redimensionnement de la fenêtre
     */
    handleWindowResize() {
        // Réajustement de l'interface si nécessaire
        if (this.app && this.app.keyboardManager) {
            this.app.keyboardManager.adjustKeyboardLayout();
        }
    }

    /**
     * Gestionnaire pour les changements de visibilité de la page
     */
    handleVisibilityChange() {
        if (document.hidden) {
            // Page cachée : sauvegarder l'état
            this.app.textProcessor.autoSave();
        } else {
            // Page visible : vérifier les mises à jour
            this.checkForUpdates();
        }
    }

    /**
     * Gestionnaire pour les erreurs JavaScript globales
     */
    handleGlobalError(event) {
        console.error('❌ Erreur JavaScript globale:', event.error);
        
        // Notification à l'utilisateur pour les erreurs critiques
        if (this.app && this.app.ui && this.app.ui.notifications) {
            this.app.ui.notifications.show({
                type: 'error',
                title: 'Erreur inattendue',
                message: 'Une erreur s\'est produite. L\'application continue de fonctionner.',
                duration: 5000
            });
        }
    }

    /**
     * Gestionnaire pour les promesses rejetées non capturées
     */
    handleUnhandledRejection(event) {
        console.error('❌ Promesse rejetée non capturée:', event.reason);
        
        // Empêcher l'affichage de l'erreur dans la console du navigateur
        event.preventDefault();
    }

    /**
     * Vérifie s'il y a des mises à jour disponibles
     */
    async checkForUpdates() {
        // Implémentation future pour vérifier les mises à jour
        console.log('🔄 Vérification des mises à jour...');
    }

    /**
     * Affiche l'aide de l'application
     */
    showHelp() {
        if (this.app && this.app.ui && this.app.ui.modal) {
            this.app.ui.modal.show({
                title: 'Aide - Clavier Arabe Universel',
                content: this.getHelpContent(),
                size: 'large'
            });
        }
    }

    /**
     * Retourne le contenu d'aide
     */
    getHelpContent() {
        return `
            <div class="help-content">
                <h4>🔤 Utilisation des claviers</h4>
                <p>Sélectionnez votre langue de saisie et utilisez le clavier virtuel ou votre clavier physique.</p>
                
                <h4>⌨️ Raccourcis clavier</h4>
                <ul>
                    <li><kbd>Ctrl/Cmd + S</kbd> : Sauvegarder le contenu</li>
                    <li><kbd>Ctrl/Cmd + C</kbd> : Copier tout le contenu</li>
                    <li><kbd>Échap</kbd> : Fermer les menus et modales</li>
                    <li><kbd>F1</kbd> : Afficher cette aide</li>
                </ul>
                
                <h4>🌐 Langues supportées</h4>
                <ul>
                    <li>العربية (Arabe standard)</li>
                    <li>الدارجة (Darija marocain)</li>
                    <li>Français</li>
                    <li>English</li>
                    <li>ⵜⴰⵎⴰⵣⵉⵖⵜ (Amazigh/Tifinagh)</li>
                </ul>
                
                <h4>📝 Fonctionnalités</h4>
                <ul>
                    <li>Conversion phonétique intelligente</li>
                    <li>Intégration Google Blogger</li>
                    <li>Export en multiple formats</li>
                    <li>Outils d'optimisation de texte</li>
                </ul>
            </div>
        `;
    }

    /**
     * Finalise l'initialisation et affiche l'application
     */
    async finishInitialization() {
        // Petite pause pour s'assurer que tout est chargé
        await Helpers.delay(500);

        // Masquer le loader et afficher l'application
        this.hideLoader();

        // Marquer l'application comme initialisée
        this.isInitialized = true;

        // Notification de bienvenue
        if (this.app && this.app.ui && this.app.ui.notifications) {
            this.app.ui.notifications.show({
                type: 'success',
                title: 'Bienvenue !',
                message: 'Clavier Arabe Universel est prêt à l\'utilisation.',
                duration: 3000
            });
        }

        // Focus sur la zone de texte principale
        const mainTextarea = document.getElementById('main-textarea');
        if (mainTextarea) {
            mainTextarea.focus();
        }
    }

    /**
     * Affiche une erreur critique
     */
    showError(message) {
        // Masquer le loader
        this.hideLoader();

        // Afficher un message d'erreur dans l'application
        if (this.appElement) {
            this.appElement.innerHTML = `
                <div class="error-container" style="
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    justify-content: center;
                    min-height: 100vh;
                    text-align: center;
                    padding: 2rem;
                    color: white;
                ">
                    <div style="font-size: 4rem; margin-bottom: 1rem;">❌</div>
                    <h2 style="margin-bottom: 1rem;">Erreur de chargement</h2>
                    <p style="margin-bottom: 2rem; max-width: 500px;">${message}</p>
                    <button onclick="window.location.reload()" style="
                        padding: 1rem 2rem;
                        background: #667eea;
                        color: white;
                        border: none;
                        border-radius: 8px;
                        cursor: pointer;
                        font-size: 1rem;
                    ">
                        Recharger la page
                    </button>
                </div>
            `;
            this.appElement.style.display = 'block';
        }
    }
}

/**
 * Fonction d'initialisation appelée au chargement de la page
 */
async function initializeApp() {
    // Attendre que le DOM soit complètement chargé
    if (document.readyState === 'loading') {
        await new Promise(resolve => {
            document.addEventListener('DOMContentLoaded', resolve);
        });
    }

    // Créer et initialiser l'application
    const mainApp = new MainApp();
    await mainApp.init();

    // Exposer l'application globalement pour le débogage (en développement)
    if (Constants.DEBUG_MODE) {
        window.app = mainApp.app;
        console.log('🔍 Application exposée globalement pour le débogage (window.app)');
    }
}

// Démarrage de l'application
initializeApp().catch(error => {
    console.error('❌ Erreur fatale lors de l\'initialisation:', error);
    
    // Affichage d'un message d'erreur de base si tout échoue
    document.body.innerHTML = `
        <div style="
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            text-align: center;
            padding: 2rem;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            font-family: Arial, sans-serif;
        ">
            <div style="font-size: 4rem; margin-bottom: 1rem;">💥</div>
            <h1 style="margin-bottom: 1rem;">Erreur fatale</h1>
            <p style="margin-bottom: 2rem; max-width: 500px;">
                L'application n'a pas pu se charger correctement. 
                Veuillez vérifier votre connexion internet et recharger la page.
            </p>
            <button onclick="window.location.reload()" style="
                padding: 1rem 2rem;
                background: rgba(255,255,255,0.2);
                color: white;
                border: 1px solid rgba(255,255,255,0.3);
                border-radius: 8px;
                cursor: pointer;
                font-size: 1rem;
            ">
                Recharger la page
            </button>
        </div>
    `;
});

// Export pour les tests (si nécessaire)
export { MainApp };

