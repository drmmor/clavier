/**
 * Module principal de l'application Clavier Arabe Universel
 * Orchestre tous les autres modules et maintient l'état global
 */

import { EventEmitter } from '../utils/helpers.js';
import { Constants } from '../utils/constants.js';

/**
 * Classe principale de l'application
 */
export class App extends EventEmitter {
    constructor(modules = {}) {
        super();
        
        // Modules principaux
        this.languageManager = modules.languageManager;
        this.keyboardManager = modules.keyboardManager;
        this.textProcessor = modules.textProcessor;
        
        // Modules d'interface utilisateur (seront définis plus tard)
        this.ui = {};
        
        // État de l'application
        this.state = {
            currentInputLanguage: 'ar',
            currentInterfaceLanguage: 'fr',
            currentKeyboard: 'arabic',
            isInitialized: false,
            activeTab: 'editor'
        };
        
        // Configuration
        this.config = {
            autoSaveInterval: 30000, // 30 secondes
            maxTextLength: 50000,
            supportedLanguages: Constants.SUPPORTED_LANGUAGES,
            defaultPreferences: Constants.DEFAULT_PREFERENCES
        };
        
        // Timers et intervalles
        this.timers = {
            autoSave: null,
            statsUpdate: null
        };
        
        console.log('📱 Application principale créée');
    }

    /**
     * Initialise l'application
     */
    async init() {
        try {
            console.log('🔧 Initialisation de l\'application principale...');
            
            // Validation des modules requis
            this.validateRequiredModules();
            
            // Configuration des gestionnaires d'événements entre modules
            this.setupModuleEventHandlers();
            
            // Initialisation de l'état par défaut
            await this.initializeDefaultState();
            
            // Démarrage des timers automatiques
            this.startAutoTimers();
            
            // Marquer comme initialisé
            this.state.isInitialized = true;
            
            // Émettre l'événement d'initialisation
            this.emit('app:initialized');
            
            console.log('✅ Application principale initialisée');
            
        } catch (error) {
            console.error('❌ Erreur lors de l\'initialisation de l\'application:', error);
            throw error;
        }
    }

    /**
     * Valide que tous les modules requis sont présents
     */
    validateRequiredModules() {
        const requiredModules = ['languageManager', 'keyboardManager', 'textProcessor'];
        
        for (const moduleName of requiredModules) {
            if (!this[moduleName]) {
                throw new Error(`Module requis manquant: ${moduleName}`);
            }
        }
        
        console.log('✅ Tous les modules requis sont présents');
    }

    /**
     * Configure les gestionnaires d'événements entre modules
     */
    setupModuleEventHandlers() {
        console.log('🔗 Configuration des gestionnaires d\'événements inter-modules...');
        
        // Gestionnaires pour le changement de langue d'interface
        this.languageManager.on('interface-language-changed', (language) => {
            this.state.currentInterfaceLanguage = language;
            this.emit('app:interface-language-changed', language);
        });
        
        // Gestionnaires pour le changement de langue de saisie
        this.languageManager.on('input-language-changed', (language) => {
            this.state.currentInputLanguage = language;
            this.updateKeyboardForLanguage(language);
            this.emit('app:input-language-changed', language);
        });
        
        // Gestionnaires pour le changement de clavier
        this.keyboardManager.on('keyboard-changed', (keyboard) => {
            this.state.currentKeyboard = keyboard;
            this.emit('app:keyboard-changed', keyboard);
        });
        
        // Gestionnaires pour les changements de texte
        this.textProcessor.on('text-changed', (data) => {
            this.emit('app:text-changed', data);
            this.updateTextStatistics();
        });
        
        // Gestionnaires pour la détection automatique de langue
        this.textProcessor.on('language-detected', (language) => {
            this.suggestLanguageChange(language);
        });
        
        console.log('✅ Gestionnaires d\'événements configurés');
    }

    /**
     * Initialise l'état par défaut de l'application
     */
    async initializeDefaultState() {
        console.log('🎯 Initialisation de l\'état par défaut...');
        
        try {
            // Définir la langue d'interface par défaut
            await this.languageManager.setInterfaceLanguage(this.state.currentInterfaceLanguage);
            
            // Définir la langue de saisie par défaut
            await this.languageManager.setInputLanguage(this.state.currentInputLanguage);
            
            // Activer le clavier par défaut
            await this.keyboardManager.setActiveKeyboard(this.state.currentKeyboard);
            
            // Initialiser le processeur de texte
            await this.textProcessor.setLanguage(this.state.currentInputLanguage);
            
            console.log('✅ État par défaut initialisé');
            
        } catch (error) {
            console.error('❌ Erreur lors de l\'initialisation de l\'état par défaut:', error);
            // Continuer avec les valeurs par défaut en cas d'erreur
        }
    }

    /**
     * Démarre les timers automatiques
     */
    startAutoTimers() {
        console.log('⏰ Démarrage des timers automatiques...');
        
        // Timer de sauvegarde automatique
        this.timers.autoSave = setInterval(() => {
            this.textProcessor.autoSave();
        }, this.config.autoSaveInterval);
        
        // Timer de mise à jour des statistiques
        this.timers.statsUpdate = setInterval(() => {
            this.updateTextStatistics();
        }, 5000); // Toutes les 5 secondes
        
        console.log('✅ Timers automatiques démarrés');
    }

    /**
     * Arrête tous les timers automatiques
     */
    stopAutoTimers() {
        Object.values(this.timers).forEach(timer => {
            if (timer) {
                clearInterval(timer);
            }
        });
        
        this.timers = {
            autoSave: null,
            statsUpdate: null
        };
        
        console.log('⏹️ Timers automatiques arrêtés');
    }

    /**
     * Définit les composants d'interface utilisateur
     */
    setUIComponents(uiComponents) {
        this.ui = { ...this.ui, ...uiComponents };
        
        // Configuration des gestionnaires d'événements UI
        this.setupUIEventHandlers();
        
        console.log('🎨 Composants UI définis:', Object.keys(this.ui));
    }

    /**
     * Configure les gestionnaires d'événements pour l'interface utilisateur
     */
    setupUIEventHandlers() {
        // Gestionnaire pour les changements d'onglets
        if (this.ui.tabManager) {
            this.ui.tabManager.on('tab-changed', (tabId) => {
                this.state.activeTab = tabId;
                this.emit('app:tab-changed', tabId);
            });
        }
        
        // Gestionnaire pour les changements de langue d'interface
        if (this.ui.languageSelector) {
            this.ui.languageSelector.on('language-selected', (language) => {
                this.changeInterfaceLanguage(language);
            });
        }
    }

    /**
     * Change la langue d'interface
     */
    async changeInterfaceLanguage(language) {
        try {
            await this.languageManager.setInterfaceLanguage(language);
            
            // Notification de succès
            if (this.ui.notifications) {
                this.ui.notifications.show({
                    type: 'success',
                    title: 'Langue changée',
                    message: `Interface changée vers ${language}`,
                    duration: 2000
                });
            }
            
        } catch (error) {
            console.error('❌ Erreur lors du changement de langue d\'interface:', error);
            
            if (this.ui.notifications) {
                this.ui.notifications.show({
                    type: 'error',
                    title: 'Erreur',
                    message: 'Impossible de changer la langue d\'interface',
                    duration: 3000
                });
            }
        }
    }

    /**
     * Change la langue de saisie
     */
    async changeInputLanguage(language) {
        try {
            await this.languageManager.setInputLanguage(language);
            
            // Notification de succès
            if (this.ui.notifications) {
                this.ui.notifications.show({
                    type: 'info',
                    title: 'Langue de saisie',
                    message: `Clavier changé vers ${language}`,
                    duration: 2000
                });
            }
            
        } catch (error) {
            console.error('❌ Erreur lors du changement de langue de saisie:', error);
            
            if (this.ui.notifications) {
                this.ui.notifications.show({
                    type: 'error',
                    title: 'Erreur',
                    message: 'Impossible de changer la langue de saisie',
                    duration: 3000
                });
            }
        }
    }

    /**
     * Met à jour le clavier selon la langue
     */
    async updateKeyboardForLanguage(language) {
        const keyboardMap = {
            'ar': 'arabic',
            'ar-ma': 'darija',
            'fr': 'french',
            'en': 'english',
            'ber': 'amazigh'
        };
        
        const keyboard = keyboardMap[language] || 'arabic';
        
        try {
            await this.keyboardManager.setActiveKeyboard(keyboard);
        } catch (error) {
            console.error('❌ Erreur lors de la mise à jour du clavier:', error);
        }
    }

    /**
     * Suggère un changement de langue basé sur la détection automatique
     */
    suggestLanguageChange(detectedLanguage) {
        if (detectedLanguage !== this.state.currentInputLanguage) {
            if (this.ui.notifications) {
                this.ui.notifications.show({
                    type: 'info',
                    title: 'Langue détectée',
                    message: `Il semble que vous écriviez en ${detectedLanguage}. Voulez-vous changer de clavier ?`,
                    duration: 5000,
                    actions: [
                        {
                            text: 'Oui',
                            action: () => this.changeInputLanguage(detectedLanguage)
                        },
                        {
                            text: 'Non',
                            action: () => {}
                        }
                    ]
                });
            }
        }
    }

    /**
     * Met à jour les statistiques de texte
     */
    updateTextStatistics() {
        const stats = this.textProcessor.getStatistics();
        this.emit('app:stats-updated', stats);
    }

    /**
     * Obtient l'état actuel de l'application
     */
    getState() {
        return { ...this.state };
    }

    /**
     * Obtient la configuration de l'application
     */
    getConfig() {
        return { ...this.config };
    }

    /**
     * Met à jour la configuration
     */
    updateConfig(newConfig) {
        this.config = { ...this.config, ...newConfig };
        this.emit('app:config-updated', this.config);
    }

    /**
     * Sauvegarde l'état actuel
     */
    saveState() {
        try {
            const stateToSave = {
                currentInputLanguage: this.state.currentInputLanguage,
                currentInterfaceLanguage: this.state.currentInterfaceLanguage,
                currentKeyboard: this.state.currentKeyboard,
                activeTab: this.state.activeTab
            };
            
            localStorage.setItem('app-state', JSON.stringify(stateToSave));
            console.log('💾 État de l\'application sauvegardé');
            
        } catch (error) {
            console.error('❌ Erreur lors de la sauvegarde de l\'état:', error);
        }
    }

    /**
     * Charge l'état sauvegardé
     */
    loadState() {
        try {
            const savedState = localStorage.getItem('app-state');
            if (savedState) {
                const parsedState = JSON.parse(savedState);
                this.state = { ...this.state, ...parsedState };
                console.log('📂 État de l\'application chargé');
                return true;
            }
        } catch (error) {
            console.error('❌ Erreur lors du chargement de l\'état:', error);
        }
        return false;
    }

    /**
     * Réinitialise l'application à son état par défaut
     */
    async reset() {
        try {
            console.log('🔄 Réinitialisation de l\'application...');
            
            // Arrêter les timers
            this.stopAutoTimers();
            
            // Réinitialiser l'état
            this.state = {
                currentInputLanguage: 'ar',
                currentInterfaceLanguage: 'fr',
                currentKeyboard: 'arabic',
                isInitialized: false,
                activeTab: 'editor'
            };
            
            // Réinitialiser les modules
            await this.textProcessor.clear();
            await this.keyboardManager.reset();
            await this.languageManager.reset();
            
            // Réinitialiser
            await this.initializeDefaultState();
            this.startAutoTimers();
            
            this.state.isInitialized = true;
            this.emit('app:reset');
            
            console.log('✅ Application réinitialisée');
            
        } catch (error) {
            console.error('❌ Erreur lors de la réinitialisation:', error);
            throw error;
        }
    }

    /**
     * Nettoie les ressources avant la fermeture
     */
    destroy() {
        console.log('🧹 Nettoyage des ressources de l\'application...');
        
        // Arrêter les timers
        this.stopAutoTimers();
        
        // Sauvegarder l'état final
        this.saveState();
        
        // Nettoyer les modules
        if (this.textProcessor) {
            this.textProcessor.destroy();
        }
        
        if (this.keyboardManager) {
            this.keyboardManager.destroy();
        }
        
        if (this.languageManager) {
            this.languageManager.destroy();
        }
        
        // Nettoyer les gestionnaires d'événements
        this.removeAllListeners();
        
        console.log('✅ Ressources nettoyées');
    }
}

// Gestionnaire pour la fermeture de la page
window.addEventListener('beforeunload', () => {
    if (window.app && window.app.destroy) {
        window.app.destroy();
    }
});

