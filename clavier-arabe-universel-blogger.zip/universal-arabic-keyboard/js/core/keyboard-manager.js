/**
 * Module de gestion des claviers virtuels (KeyboardManager)
 * Gère le chargement, l'activation et l'affichage des différents claviers
 */

import { EventEmitter, Helpers } from "../utils/helpers.js";
import { Constants } from "../utils/constants.js";

export class KeyboardManager extends EventEmitter {
    constructor() {
        super();
        this.activeKeyboardId = Constants.DEFAULT_PREFERENCES.keyboardLayout; // ID du clavier actif
        this.keyboardLayouts = {}; // Contient les dispositions de clavier chargées
        this.keyboardElement = null; // Référence à l'élément DOM du clavier virtuel
        this.shiftActive = false; // État de la touche Shift
        this.altGrActive = false; // État de la touche AltGr
        console.log("⌨️ KeyboardManager créé");
    }

    /**
     * Initialise le gestionnaire de claviers
     */
    async init() {
        console.log("🔧 Initialisation du KeyboardManager...");
        this.keyboardElement = document.getElementById("virtual-keyboard");
        if (!this.keyboardElement) {
            console.error("❌ Élément #virtual-keyboard non trouvé dans le DOM.");
            throw new Error("Élément #virtual-keyboard manquant.");
        }
        await this.loadKeyboardConfigs();
        this.renderKeyboard();
        this.setupEventListeners();
        console.log("✅ KeyboardManager initialisé");
    }

    /**
     * Charge toutes les configurations de clavier définies dans les constantes
     */
    async loadKeyboardConfigs() {
        console.log("📊 Chargement des dispositions de clavier...");
        for (const keyboardId in Constants.KEYBOARD_CONFIGS) {
            try {
                const config = Constants.KEYBOARD_CONFIGS[keyboardId];
                const layout = await Helpers.loadJSON(`${Constants.PATHS.KEYBOARDS}${config.layout}.json`);
                this.keyboardLayouts[keyboardId] = layout;
                console.log(`  Chargé: ${keyboardId} (${config.layout}.json)`);
            } catch (error) {
                console.warn(`⚠️ Impossible de charger la disposition pour le clavier ${keyboardId}:`, error);
                this.keyboardLayouts[keyboardId] = { keys: [] }; // Charger une disposition vide
            }
        }
        console.log("✅ Dispositions de clavier chargées:", Object.keys(this.keyboardLayouts));
    }

    /**
     * Définit le clavier actif et le rend
     * @param {string} keyboardId - ID du clavier à activer (ex: 'arabic', 'french')
     */
    async setActiveKeyboard(keyboardId) {
        if (!this.keyboardLayouts[keyboardId]) {
            console.warn(`Clavier inconnu: ${keyboardId}`);
            return;
        }
        this.activeKeyboardId = keyboardId;
        this.shiftActive = false;
        this.altGrActive = false;
        this.renderKeyboard();
        this.emit(Constants.EVENTS.KEYBOARD_CHANGED, keyboardId);
        console.log(`✅ Clavier actif défini sur: ${keyboardId}`);
    }

    /**
     * Rend le clavier virtuel dans le DOM
     */
    renderKeyboard() {
        if (!this.keyboardElement) return;

        const keyboardConfig = Constants.KEYBOARD_CONFIGS[this.activeKeyboardId];
        const layout = this.keyboardLayouts[this.activeKeyboardId];

        if (!layout || !layout.keys) {
            this.keyboardElement.innerHTML = 
                `<div class="keyboard-error">Impossible de charger le clavier pour ${keyboardConfig.name}.</div>`;
            return;
        }

        let keyboardHtml = 
            `<div class="keyboard-title">${keyboardConfig.name}</div>`;

        layout.keys.forEach(row => {
            keyboardHtml += `<div class="keyboard-row">`;
            row.forEach(key => {
                const displayKey = this.getDisplayKey(key);
                const keyClass = this.getKeyClass(key);
                keyboardHtml += 
                    `<button class="key ${keyClass}" data-key="${key.code || key.key}" data-type="${key.type || 'char'}">
                        ${displayKey}
                    </button>`;
            });
            keyboardHtml += `</div>`;
        });

        this.keyboardElement.innerHTML = keyboardHtml;
        this.updateKeyStates();
    }

    /**
     * Retourne la touche à afficher en fonction de l'état de Shift/AltGr
     * @param {object} keyConfig - Configuration de la touche
     * @returns {string} - Caractère à afficher
     */
    getDisplayKey(keyConfig) {
        if (this.altGrActive && keyConfig.altGr) {
            return keyConfig.altGr;
        } else if (this.shiftActive && keyConfig.shift) {
            return keyConfig.shift;
        } else {
            return keyConfig.key;
        }
    }

    /**
     * Retourne les classes CSS pour une touche
     * @param {object} keyConfig - Configuration de la touche
     * @returns {string} - Classes CSS
     */
    getKeyClass(keyConfig) {
        let classes = keyConfig.class || "";
        if (keyConfig.type === "space") classes += " space";
        if (keyConfig.type === "special") classes += " special";
        if (keyConfig.code === "ShiftLeft" || keyConfig.code === "ShiftRight") {
            if (this.shiftActive) classes += " active";
        }
        if (keyConfig.code === "AltGraph") {
            if (this.altGrActive) classes += " active";
        }
        return classes.trim();
    }

    /**
     * Met à jour l'état visuel des touches (ex: Shift actif)
     */
    updateKeyStates() {
        this.keyboardElement.querySelectorAll(".key").forEach(button => {
            const keyConfig = this.getKeyConfigFromButton(button);
            if (keyConfig) {
                button.textContent = this.getDisplayKey(keyConfig);
                button.className = `key ${this.getKeyClass(keyConfig)}`;
            }
        });
    }

    /**
     * Récupère la configuration de la touche à partir d'un bouton DOM
     * @param {HTMLElement} button - Élément bouton de la touche
     * @returns {object|null} - Configuration de la touche
     */
    getKeyConfigFromButton(button) {
        const layout = this.keyboardLayouts[this.activeKeyboardId];
        if (!layout || !layout.keys) return null;

        const keyCode = button.dataset.key;
        for (const row of layout.keys) {
            for (const key of row) {
                if (key.code === keyCode || key.key === keyCode) {
                    return key;
                }
            }
        }
        return null;
    }

    /**
     * Configure les écouteurs d'événements pour le clavier virtuel
     */
    setupEventListeners() {
        this.keyboardElement.addEventListener("click", this.handleKeyClick.bind(this));
        // Écouteurs pour le clavier physique pour synchroniser l'état de Shift/AltGr
        document.addEventListener("keydown", this.handlePhysicalKeydown.bind(this));
        document.addEventListener("keyup", this.handlePhysicalKeyup.bind(this));
    }

    /**
     * Gère le clic sur une touche du clavier virtuel
     * @param {Event} event - L'événement de clic
     */
    handleKeyClick(event) {
        const target = event.target.closest(".key");
        if (!target) return;

        const keyType = target.dataset.type;
        const keyCode = target.dataset.key;
        let charToEmit = target.textContent;

        switch (keyType) {
            case "char":
                this.emit(Constants.EVENTS.KEY_PRESSED, charToEmit);
                break;
            case "special":
                if (keyCode === "ShiftLeft" || keyCode === "ShiftRight") {
                    this.shiftActive = !this.shiftActive;
                    this.altGrActive = false; // Désactiver AltGr si Shift est activé
                    this.renderKeyboard();
                } else if (keyCode === "AltGraph") {
                    this.altGrActive = !this.altGrActive;
                    this.shiftActive = false; // Désactiver Shift si AltGr est activé
                    this.renderKeyboard();
                } else if (keyCode === "Backspace") {
                    this.emit(Constants.EVENTS.KEY_PRESSED, "Backspace");
                } else if (keyCode === "Enter") {
                    this.emit(Constants.EVENTS.KEY_PRESSED, "Enter");
                } else if (keyCode === "Tab") {
                    this.emit(Constants.EVENTS.KEY_PRESSED, "Tab");
                } else if (keyCode === "Space") {
                    this.emit(Constants.EVENTS.KEY_PRESSED, " ");
                } else {
                    this.emit(Constants.EVENTS.KEY_PRESSED, charToEmit); // Pour les autres touches spéciales
                }
                break;
            case "space":
                this.emit(Constants.EVENTS.KEY_PRESSED, " ");
                break;
            default:
                this.emit(Constants.EVENTS.KEY_PRESSED, charToEmit);
                break;
        }

        // Après avoir tapé un caractère, désactiver Shift/AltGr si ce n'est pas une touche de verrouillage
        if (keyType === "char" || keyType === "space") {
            if (this.shiftActive) {
                this.shiftActive = false;
                this.renderKeyboard();
            }
            if (this.altGrActive) {
                this.altGrActive = false;
                this.renderKeyboard();
            }
        }
    }

    /**
     * Gère les événements keydown du clavier physique pour synchroniser l'état de Shift/AltGr
     * @param {KeyboardEvent} event - L'événement clavier
     */
    handlePhysicalKeydown(event) {
        if (event.code === "ShiftLeft" || event.code === "ShiftRight") {
            if (!this.shiftActive) {
                this.shiftActive = true;
                this.altGrActive = false;
                this.renderKeyboard();
            }
        } else if (event.code === "AltGraph") {
            if (!this.altGrActive) {
                this.altGrActive = true;
                this.shiftActive = false;
                this.renderKeyboard();
            }
        }
    }

    /**
     * Gère les événements keyup du clavier physique pour synchroniser l'état de Shift/AltGr
     * @param {KeyboardEvent} event - L'événement clavier
     */
    handlePhysicalKeyup(event) {
        if (event.code === "ShiftLeft" || event.code === "ShiftRight") {
            this.shiftActive = false;
            this.renderKeyboard();
        } else if (event.code === "AltGraph") {
            this.altGrActive = false;
            this.renderKeyboard();
        }
    }

    /**
     * Récupère la disposition du clavier actif
     * @returns {object} - La disposition du clavier actif
     */
    getActiveKeyboardLayout() {
        return this.keyboardLayouts[this.activeKeyboardId];
    }

    /**
     * Récupère l'ID du clavier actif
     * @returns {string}
     */
    getActiveKeyboardId() {
        return this.activeKeyboardId;
    }

    /**
     * Ajuste la disposition du clavier (utile pour le responsive)
     */
    adjustKeyboardLayout() {
        // Implémentation future si des ajustements dynamiques sont nécessaires
        // Par exemple, redimensionner les touches en fonction de la largeur de l'écran
        console.log("🔄 Ajustement de la disposition du clavier...");
    }

    /**
     * Réinitialise le gestionnaire de claviers
     */
    async reset() {
        this.activeKeyboardId = Constants.DEFAULT_PREFERENCES.keyboardLayout;
        this.shiftActive = false;
        this.altGrActive = false;
        this.renderKeyboard();
        console.log("🔄 KeyboardManager réinitialisé");
    }

    /**
     * Nettoie les ressources
     */
    destroy() {
        this.removeAllListeners();
        if (this.keyboardElement) {
            this.keyboardElement.removeEventListener("click", this.handleKeyClick);
        }
        document.removeEventListener("keydown", this.handlePhysicalKeydown);
        document.removeEventListener("keyup", this.handlePhysicalKeyup);
        console.log("🗑️ KeyboardManager détruit");
    }
}


