
/**
 * Module de gestion des langues (LanguageManager)
 * Gère la langue de l'interface utilisateur et la langue de saisie
 * Charge les traductions et les configurations de langue
 */

import { EventEmitter, Helpers } from "../utils/helpers.js";
import { Constants } from "../utils/constants.js";
import { Storage } from "./storage.js";

export class LanguageManager extends EventEmitter {
    constructor() {
        super();
        this.interfaceLanguage = Constants.DEFAULT_PREFERENCES.interfaceLanguage;
        this.inputLanguage = Constants.DEFAULT_PREFERENCES.inputLanguage;
        this.translations = {};
        this.languageConfigs = {};
        this.currentDirection = Constants.SUPPORTED_LANGUAGES[this.inputLanguage].direction;
        console.log("🌐 LanguageManager créé");
    }

    /**
     * Initialise le gestionnaire de langues
     */
    async init() {
        console.log("🔧 Initialisation du LanguageManager...");
        await this.loadAllLanguageConfigs();
        await this.loadTranslations(this.interfaceLanguage);
        this.applyInterfaceLanguage(this.interfaceLanguage);
        this.applyInputLanguage(this.inputLanguage);
        console.log("✅ LanguageManager initialisé");
    }

    /**
     * Charge toutes les configurations de langue supportées
     */
    async loadAllLanguageConfigs() {
        console.log("📊 Chargement des configurations de langue...");
        for (const langCode in Constants.SUPPORTED_LANGUAGES) {
            try {
                const config = await Helpers.loadJSON(`${Constants.PATHS.LANGUAGES}${langCode}.json`);
                this.languageConfigs[langCode] = config;
            } catch (error) {
                console.warn(`⚠️ Impossible de charger la configuration pour la langue ${langCode}:`, error);
                this.languageConfigs[langCode] = {}; // Charger une config vide pour éviter les erreurs
            }
        }
        console.log("✅ Configurations de langue chargées:", Object.keys(this.languageConfigs));
    }

    /**
     * Charge les traductions pour une langue donnée
     * @param {string} langCode - Code de la langue (ex: 'fr', 'en', 'ar')
     */
    async loadTranslations(langCode) {
        console.log(`🌍 Chargement des traductions pour ${langCode}...`);
        try {
            const translations = await Helpers.loadJSON(`${Constants.PATHS.TRANSLATIONS}${langCode}.json`);
            this.translations = translations;
            console.log(`✅ Traductions pour ${langCode} chargées.`);
        } catch (error) {
            console.error(`❌ Erreur lors du chargement des traductions pour ${langCode}:`, error);
            // Fallback vers l'anglais si les traductions ne peuvent pas être chargées
            if (langCode !== 'en') {
                console.warn('Tentative de chargement des traductions anglaises par défaut.');
                try {
                    const defaultTranslations = await Helpers.loadJSON(`${Constants.PATHS.TRANSLATIONS}en.json`);
                    this.translations = defaultTranslations;
                    console.log('✅ Traductions anglaises chargées par défaut.');
                } catch (defaultError) {
                    console.error('❌ Impossible de charger les traductions anglaises par défaut:', defaultError);
                    this.translations = {}; // Aucune traduction disponible
                }
            }
            throw error; // Propager l'erreur pour que l'application puisse la gérer
        }
    }

    /**
     * Définit la langue de l'interface utilisateur
     * @param {string} langCode - Code de la langue
     */
    async setInterfaceLanguage(langCode) {
        if (this.interfaceLanguage === langCode) {
            return; // Pas de changement
        }
        if (!Constants.INTERFACE_LANGUAGES[langCode]) {
            console.warn(`Langue d'interface non supportée: ${langCode}`);
            return;
        }

        try {
            await this.loadTranslations(langCode);
            this.interfaceLanguage = langCode;
            this.applyInterfaceLanguage(langCode);
            Storage.savePreferences({ interfaceLanguage: langCode });
            this.emit(Constants.EVENTS.INTERFACE_LANGUAGE_CHANGED, langCode);
            console.log(`✅ Langue d'interface définie sur ${langCode}`);
        } catch (error) {
            console.error(`❌ Erreur lors de la définition de la langue d'interface sur ${langCode}:`, error);
            throw error;
        }
    }

    /**
     * Applique la langue de l'interface utilisateur au DOM
     * @param {string} langCode - Code de la langue
     */
    applyInterfaceLanguage(langCode) {
        document.documentElement.lang = langCode;
        document.documentElement.dir = Constants.INTERFACE_LANGUAGES[langCode].direction;
        this.updateDOMTranslations();
    }

    /**
     * Met à jour tous les éléments du DOM avec les traductions
     */
    updateDOMTranslations() {
        document.querySelectorAll('[data-i18n]').forEach(element => {
            const key = element.getAttribute('data-i18n');
            const translation = this.getTranslation(key);
            if (translation) {
                element.textContent = translation;
            }
        });
    }

    /**
     * Définit la langue de saisie
     * @param {string} langCode - Code de la langue
     */
    async setInputLanguage(langCode) {
        if (this.inputLanguage === langCode) {
            return; // Pas de changement
        }
        if (!Constants.SUPPORTED_LANGUAGES[langCode]) {
            console.warn(`Langue de saisie non supportée: ${langCode}`);
            return;
        }

        this.inputLanguage = langCode;
        this.currentDirection = Constants.SUPPORTED_LANGUAGES[langCode].direction;
        this.applyInputLanguage(langCode);
        Storage.savePreferences({ inputLanguage: langCode });
        this.emit(Constants.EVENTS.INPUT_LANGUAGE_CHANGED, langCode);
        console.log(`✅ Langue de saisie définie sur ${langCode}`);
    }

    /**
     * Applique la langue de saisie (direction du texte, police)
     * @param {string} langCode - Code de la langue
     */
    applyInputLanguage(langCode) {
        const mainTextarea = document.getElementById('main-textarea');
        if (mainTextarea) {
            mainTextarea.dir = this.currentDirection;
            mainTextarea.style.fontFamily = Constants.SUPPORTED_LANGUAGES[langCode].fontFamily;
        }
        const currentLangIndicator = document.getElementById('current-language');
        if (currentLangIndicator) {
            currentLangIndicator.textContent = this.getTranslation(`languages.${langCode}`);
        }
    }

    /**
     * Récupère une traduction pour une clé donnée
     * @param {string} key - Clé de traduction (ex: 'app.title')
     * @returns {string} - La traduction ou la clé si non trouvée
     */
    getTranslation(key) {
        const keys = key.split('.');
        let result = this.translations;
        for (const k of keys) {
            if (result && typeof result === 'object' && result.hasOwnProperty(k)) {
                result = result[k];
            } else {
                return `[${key}]`; // Retourne la clé si la traduction n'est pas trouvée
            }
        }
        return result;
    }

    /**
     * Récupère la configuration d'une langue spécifique
     * @param {string} langCode - Code de la langue
     * @returns {object} - La configuration de la langue
     */
    getLanguageConfig(langCode) {
        return this.languageConfigs[langCode] || {};
    }

    /**
     * Récupère la langue d'interface actuelle
     * @returns {string}
     */
    getInterfaceLanguage() {
        return this.interfaceLanguage;
    }

    /**
     * Récupère la langue de saisie actuelle
     * @returns {string}
     */
    getInputLanguage() {
        return this.inputLanguage;
    }

    /**
     * Récupère la direction du texte actuelle (rtl ou ltr)
     * @returns {string}
     */
    getCurrentDirection() {
        return this.currentDirection;
    }

    /**
     * Réinitialise le gestionnaire de langues
     */
    async reset() {
        this.interfaceLanguage = Constants.DEFAULT_PREFERENCES.interfaceLanguage;
        this.inputLanguage = Constants.DEFAULT_PREFERENCES.inputLanguage;
        this.translations = {};
        this.languageConfigs = {};
        await this.init();
        console.log("🔄 LanguageManager réinitialisé");
    }

    /**
     * Nettoie les ressources
     */
    destroy() {
        this.removeAllListeners();
        console.log("🗑️ LanguageManager détruit");
    }
}


