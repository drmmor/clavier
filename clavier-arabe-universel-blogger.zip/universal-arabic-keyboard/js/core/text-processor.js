/**
 * Module de traitement du texte (TextProcessor)
 * Gère la saisie de texte, la détection de langue, les statistiques et la sauvegarde automatique.
 */

import { EventEmitter, Helpers } from "../utils/helpers.js";
import { Constants } from "../utils/constants.js";
import { Storage } from "./storage.js";

export class TextProcessor extends EventEmitter {
    constructor() {
        super();
        this.textarea = null; // Référence à l'élément textarea principal
        this.currentText = "";
        this.currentLanguage = Constants.DEFAULT_PREFERENCES.inputLanguage;
        this.autoSaveInterval = null;
        console.log("📝 TextProcessor créé");
    }

    /**
     * Initialise le processeur de texte
     */
    async init() {
        console.log("🔧 Initialisation du TextProcessor...");
        this.textarea = document.getElementById("main-textarea");
        if (!this.textarea) {
            console.error("❌ Élément #main-textarea non trouvé dans le DOM.");
            throw new Error("Élément #main-textarea manquant.");
        }

        // Charger le contenu sauvegardé
        this.currentText = Storage.getTextContent();
        this.textarea.value = this.currentText;

        this.setupEventListeners();
        this.updateTextStatistics();
        console.log("✅ TextProcessor initialisé");
    }

    /**
     * Configure les écouteurs d'événements pour la zone de texte
     */
    setupEventListeners() {
        this.textarea.addEventListener("input", Helpers.debounce(this.handleTextInput.bind(this), Constants.LIMITS.DEBOUNCE_DELAY));
        this.textarea.addEventListener("keydown", this.handleKeyDown.bind(this));
    }

    /**
     * Gère l'entrée de texte dans la zone de texte
     */
    handleTextInput() {
        const newText = this.textarea.value;
        if (newText !== this.currentText) {
            this.currentText = newText;
            this.emit(Constants.EVENTS.TEXT_CHANGED, { text: this.currentText, length: this.currentText.length });
            this.autoSave();
            this.detectAndSuggestLanguage();
        }
    }

    /**
     * Gère les événements de touche pour la zone de texte
     * @param {KeyboardEvent} event
     */
    handleKeyDown(event) {
        // Empêcher le comportement par défaut de la touche Tab
        if (event.key === "Tab") {
            event.preventDefault();
            const start = this.textarea.selectionStart;
            const end = this.textarea.selectionEnd;

            // Insérer 4 espaces à la position du curseur
            this.textarea.value = this.textarea.value.substring(0, start) + "    " + this.textarea.value.substring(end);

            // Placer le curseur après les espaces insérés
            this.textarea.selectionStart = this.textarea.selectionEnd = start + 4;
            this.handleTextInput(); // Déclencher la mise à jour du texte
        }
    }

    /**
     * Ajoute un caractère à la position actuelle du curseur
     * @param {string} char - Le caractère à ajouter
     */
    addChar(char) {
        const start = this.textarea.selectionStart;
        const end = this.textarea.selectionEnd;
        const value = this.textarea.value;

        if (char === "Backspace") {
            if (start === end && start > 0) {
                this.textarea.value = value.substring(0, start - 1) + value.substring(end);
                this.textarea.selectionStart = this.textarea.selectionEnd = start - 1;
            } else if (start !== end) {
                this.textarea.value = value.substring(0, start) + value.substring(end);
                this.textarea.selectionStart = this.textarea.selectionEnd = start;
            }
        } else if (char === "Enter") {
            this.textarea.value = value.substring(0, start) + "\n" + value.substring(end);
            this.textarea.selectionStart = this.textarea.selectionEnd = start + 1;
        } else if (char === "Tab") {
            this.textarea.value = value.substring(0, start) + "    " + value.substring(end);
            this.textarea.selectionStart = this.textarea.selectionEnd = start + 4;
        } else {
            this.textarea.value = value.substring(0, start) + char + value.substring(end);
            this.textarea.selectionStart = this.textarea.selectionEnd = start + char.length;
        }
        this.handleTextInput(); // Déclencher la mise à jour du texte
    }

    /**
     * Définit le texte de la zone de texte
     * @param {string} text - Le nouveau texte
     */
    setText(text) {
        this.textarea.value = text;
        this.handleTextInput();
    }

    /**
     * Récupère le texte actuel de la zone de texte
     * @returns {string}
     */
    getText() {
        return this.currentText;
    }

    /**
     * Efface tout le texte de la zone de texte
     */
    clear() {
        this.setText("");
        console.log("🗑️ Contenu de l'éditeur effacé.");
    }

    /**
     * Copie le contenu de la zone de texte dans le presse-papiers
     */
    async copyContent() {
        try {
            await Helpers.copyToClipboard(this.currentText);
            this.emit("notification:show", { type: "success", message: "Texte copié dans le presse-papiers !" });
            console.log("✅ Contenu copié dans le presse-papiers.");
        } catch (error) {
            this.emit("notification:show", { type: "error", message: "Impossible de copier le texte." });
            console.error("❌ Erreur lors de la copie du contenu:", error);
        }
    }

    /**
     * Sauvegarde automatiquement le contenu dans le stockage local
     */
    autoSave() {
        Storage.saveTextContent(this.currentText);
        console.log("💾 Contenu sauvegardé automatiquement.");
    }

    /**
     * Met à jour les statistiques de texte et les émet
     */
    updateTextStatistics() {
        const stats = Helpers.getTextStatistics(this.currentText);
        this.emit(Constants.EVENTS.TEXT_STATS_UPDATED, stats);
    }

    /**
     * Détecte la langue du texte et suggère un changement si nécessaire
     */
    detectAndSuggestLanguage() {
        if (Constants.DEFAULT_PREFERENCES.autoDetectLanguage) {
            const detectedLang = Helpers.detectLanguage(this.currentText);
            if (detectedLang && detectedLang !== this.currentLanguage) {
                this.emit(Constants.EVENTS.LANGUAGE_DETECTED, detectedLang);
            }
        }
    }

    /**
     * Définit la langue de saisie pour le processeur de texte
     * @param {string} langCode - Code de la langue
     */
    setLanguage(langCode) {
        this.currentLanguage = langCode;
        const langConfig = Constants.SUPPORTED_LANGUAGES[langCode];
        if (this.textarea && langConfig) {
            this.textarea.dir = langConfig.direction;
            this.textarea.style.fontFamily = langConfig.fontFamily;
        }
    }

    /**
     * Réinitialise le processeur de texte
     */
    reset() {
        this.clear();
        this.currentLanguage = Constants.DEFAULT_PREFERENCES.inputLanguage;
        this.setLanguage(this.currentLanguage);
        this.updateTextStatistics();
        console.log("🔄 TextProcessor réinitialisé");
    }

    /**
     * Nettoie les ressources
     */
    destroy() {
        this.removeAllListeners();
        if (this.textarea) {
            this.textarea.removeEventListener("input", this.handleTextInput);
            this.textarea.removeEventListener("keydown", this.handleKeyDown);
        }
        if (this.autoSaveInterval) {
            clearInterval(this.autoSaveInterval);
        }
        console.log("🗑️ TextProcessor détruit");
    }
}


