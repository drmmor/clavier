/**
 * Module de gestion du stockage local (localStorage)
 * Gère la persistance des préférences utilisateur et du contenu de l'éditeur
 */

import { Constants } from '../utils/constants.js';
import { Helpers } from '../utils/helpers.js';

export class Storage {
    /**
     * Vérifie si localStorage est supporté par le navigateur
     * @returns {boolean}
     */
    static isSupported() {
        try {
            const testKey = '__storage_test__';
            localStorage.setItem(testKey, testKey);
            localStorage.removeItem(testKey);
            return true;
        } catch (e) {
            return false;
        }
    }

    /**
     * Sauvegarde les préférences utilisateur
     * @param {object} preferences - Objet des préférences à sauvegarder
     */
    static savePreferences(preferences) {
        if (Storage.isSupported()) {
            Helpers.saveToStorage(Constants.STORAGE_KEYS.PREFERENCES, preferences);
        } else {
            console.warn('localStorage non supporté, les préférences ne seront pas sauvegardées.');
        }
    }

    /**
     * Charge les préférences utilisateur
     * @returns {object} - Les préférences sauvegardées ou les préférences par défaut
     */
    static getPreferences() {
        if (Storage.isSupported()) {
            const savedPreferences = Helpers.loadFromStorage(Constants.STORAGE_KEYS.PREFERENCES);
            return { ...Constants.DEFAULT_PREFERENCES, ...savedPreferences };
        } else {
            return Constants.DEFAULT_PREFERENCES;
        }
    }

    /**
     * Sauvegarde le contenu de l'éditeur
     * @param {string} content - Contenu de l'éditeur à sauvegarder
     */
    static saveTextContent(content) {
        if (Storage.isSupported()) {
            Helpers.saveToStorage(Constants.STORAGE_KEYS.TEXT_CONTENT, content);
        } else {
            console.warn('localStorage non supporté, le contenu ne sera pas sauvegardé.');
        }
    }

    /**
     * Charge le contenu de l'éditeur
     * @returns {string} - Le contenu sauvegardé ou une chaîne vide
     */
    static getTextContent() {
        if (Storage.isSupported()) {
            return Helpers.loadFromStorage(Constants.STORAGE_KEYS.TEXT_CONTENT, '');
        } else {
            return '';
        }
    }

    /**
     * Sauvegarde l'état de l'application
     * @param {object} appState - État de l'application à sauvegarder
     */
    static saveAppState(appState) {
        if (Storage.isSupported()) {
            Helpers.saveToStorage(Constants.STORAGE_KEYS.APP_STATE, appState);
        } else {
            console.warn('localStorage non supporté, l\'état de l\'application ne sera pas sauvegardé.');
        }
    }

    /**
     * Charge l'état de l'application
     * @returns {object} - L'état sauvegardé ou null
     */
    static getAppState() {
        if (Storage.isSupported()) {
            return Helpers.loadFromStorage(Constants.STORAGE_KEYS.APP_STATE, null);
        } else {
            return null;
        }
    }

    /**
     * Efface toutes les données de l'application du stockage local
     */
    static clearAll() {
        if (Storage.isSupported()) {
            for (const key in Constants.STORAGE_KEYS) {
                localStorage.removeItem(Constants.STORAGE_KEYS[key]);
            }
            console.log('Toutes les données de l\'application ont été effacées du stockage local.');
        } else {
            console.warn('localStorage non supporté, impossible d\'effacer les données.');
        }
    }

    /**
     * Efface une clé spécifique du stockage local
     * @param {string} key - La clé à effacer
     */
    static clear(key) {
        if (Storage.isSupported()) {
            localStorage.removeItem(key);
            console.log(`Clé '${key}' effacée du stockage local.`);
        } else {
            console.warn('localStorage non supporté, impossible d\'effacer la clé.');
        }
    }
}


